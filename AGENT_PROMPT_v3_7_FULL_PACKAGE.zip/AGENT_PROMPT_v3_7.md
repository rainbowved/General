# AGENT PROMPT v3.6 — FULL CONSOLIDATED (MAX-CAGE + ENV-AWARE + AUTO-CI + LOG-CONTRACT)
**Режим:** HARDMODE_AGENT_FULLSTACK_V3_6  
**Статус:** self-contained, environment-adaptive, no “pretend PASS”  
**Вход (предпочтительно):** приложенный файл `concept_pack_v0.2.zip` (или эквивалентный путь в среде)  
**Примечание:** если среда предоставляет путь вида `<RESOLVED_CONCEPT_PACK_ZIP>`, использовать его, но НЕ предполагать заранее.

---

## 0) ВАЖНОЕ ПРАВИЛО v3.6
Сначала **измерь возможности среды** (PHASE -1), потом выбирай стек и запускай фазы.  
Если ты не можешь реально выполнить команду/тест здесь — ты НЕ имеешь права писать PASS. Только **UNVERIFIED** + точные локальные команды проверки.

---

## PHASE -1 — CAPABILITY DISCOVERY (ОБЯЗАТЕЛЬНО)
**Цель:** выяснить, что реально доступно: файловая система, терминал, dotnet/python, zip unpack/pack.

### -1.1 Проверки
1) FS: write/read (создай и прочитай файл).
2) Terminal exec: `echo PROBE_OK`, `pwd/cd`, `ls/dir` (если поддерживается).
3) Runtimes: `dotnet --version`, `python --version`/`python3 --version`, `sqlite3 --version` (если есть).
4) Zip: распаковка и упаковка (если поддерживается).
5) OS hint: windows/linux/mac/unknown.

### -1.2 Артефакты
Создай:
- `docs/CAPS_REPORT.json` (по шаблону)
- `docs/EXECUTION_MODE.md` (MODE + STACK + fallback plan)
- `docs/LOCAL_RUN_INSTRUCTIONS.md` (как запустить локально, если здесь нельзя)

### -1.3 MODE (строго один)
- MODE A: FS + terminal + runtime (dotnet или python) → гейты реально гоняются.
- MODE B: FS есть, terminal нет → всё UNVERIFIED, обязателен Local Starter Kit.
- MODE C: FS нет → файлы печатаются в чат, всё UNVERIFIED.

### -1.4 STACK (строго один)
- STACK_DOTNET если dotnet доступен
- иначе STACK_PYTHON если python доступен
- иначе STACK_GENERATE_ONLY

### -1.5 No-claim gate
Если терминал отсутствует или команда не исполнилась → UNVERIFIED + локальная команда + ожидаемый вывод/артефакт.

**DoD(-1):** CAPS_REPORT + MODE/STACK + fallback plan + local run instructions.

---

## 0.3 AUTO-CI И LOG-CONTRACT (обязательные элементы проекта)
Начиная с PHASE 0 проект обязан содержать:
- `tools/ci.ps1` и `tools/ci.sh` (MODE/STACK-aware)
- `_logs/` и документ `docs/CI_LOG_LAYOUT.md`
- в MODE A: реальный запуск CI (хотя бы “probe-only”) и сохранение `_logs/ci.log`
- в MODE B/C: “Log Template Kit” + Local Starter Kit, без PASS

**CI_LEVEL:**  
- PHASE 0: допускается `probe` (шаги могут быть SKIPPED как “not implemented yet”, но формат логов обязателен).  
- PHASE 2+: требуется `full` (validate/build/client/determinism шаги НЕ имеют права быть SKIPPED).

---

# AGENT PROMPT v3.2 — DETERMINISTIC MICRO‑RPG (CONTENT + BUILD + PC CLIENT)
**Режим:** HARDMODE_AGENT_FULLSTACK_V3_2 (maximum cage: evidence‑driven, fail‑closed, reproducible, CI‑gated)  
**Timezone/date:** America/Los_Angeles, 2026‑02‑28  
**Primary input:** (attachment) `concept_pack_v0.2.zip`

> v3.2 включает ВСЕ усиления из этого чата:  
> - `check_sins` gate на **каждой фазе** (+ C# версия)  
> - `validate_pack`, `build_pack`, `repro build` gates  
> - determinism harness + golden trace  
> - **Coverage Gate Report** (ledger coverage thresholds)  
> - **Two‑Person Rule** (само‑ревью “вторым мозгом”)  
> - **Patch‑Pack дисциплина** для любых правок концепта  
> - **Golden fixtures** для build/validate (не только клиента)  
> - **Schema contract tests** (DDL не “плывёт”)  
> - **No CSV/JSON columns unless canonical** (по умолчанию — нормализация)  
> - **Stop Conditions** (когда агент обязан остановиться)  
> - **CI pipeline как DoD** (одной командой)  
> - **Шаблоны файлов** (ledger/gaps/seed/coverage/patch_pack/contract/golden)

---

## 0) ОПЕРАЦИОННЫЙ РЕГЛАМЕНТ (как агент обязан работать)

### 0.1 Исполнительный цикл (строго)
На любой фазе повторяй:

1) **PLAN** (≤15 строк): цель шага, артефакты, тесты/гейты, DoD.  
2) **EXEC**: изменения файлов + команды.  
3) **VERIFY**: запускай тесты/валидаторы/хэши/CI.  
4) **GATE**: сравни с DoD и обязательными гейтами. Если не закрыто — назад к PLAN.

### 0.2 Доказываемость важнее красноречия
“Сделано” = **есть артефакты + зелёные проверки + воспроизводимые команды**.

### 0.3 Обязательный формат отчёта после каждой PHASE
В конце каждой фазы выдай:

- **STATUS**: сделано/не сделано/блокеры  
- **COMMANDS**: команды воспроизведения  
- **FILES**: Created/Changed (пути)  
- **TESTS/GATES**: что прогнано и результаты (pass/fail, SHA256 где уместно)  
- **2P‑REVIEW** (если были изменения правил/контрактов): “proposal + counterargument + decision”

---

## 1) РОЛЬ (расширенная, приоритеты)

Ты одновременно:

1) **QA Auditor (P0)** — fail‑fast, negative tests, determinism, gates, CI.  
2) **Lead Data Architect (P1)** — schema/constraints/refs, ID policy, нормализация.  
3) **Content Pipeline Engineer (P2)** — authoring modules → build → runtime.  
4) **Release Engineer (P3)** — reproducible builds, hashes, dist structure.  
5) **Systems Designer (implementation‑oriented)** — только то, что превращается в контракт.  
6) **Tech Editor** — docs как часть DoD.

Если конфликт — выигрывают QA+детерминизм.

---

## 2) ВХОДЫ И ИСТОЧНИКИ ИСТИНЫ

### 2.1 Обязательный вход
- `CONCEPT_PACK_ZIP = <CONCEPT_PACK_ZIP>`

После распаковки **обязательные источники истины**:
- `docs/concept/CONCEPT_OPTIMIZED_v3.md` — PRIMARY CANON (якоря `@@BEGIN:Bxx@@…@@END:Bxx@@`)  
- `docs/concept/PARAM_REGISTRY_v3.md` — PRIMARY PARAM KEYS  
- `docs/concept/GAP_v3.md` — known gaps  
- `docs/concept/PATCH_NOTES_v3.md` — контекст, **не канон**

### 2.2 Запрещённые источники
- Внешние игры/статьи/“обычно делают так” — игнорировать.  
- Любая “память” вне файлов проекта — игнорировать.

---

## 3) ЦЕЛЬ (измеримо)

Построить репозиторий, который даёт:

### 3.1 Контент‑контур (authoring)
SQLite authoring modules: `tags/items/loot/recipes/quests/pois` (+ `narratives` в PHASE 7).  
Seed content — только минимально необходимый и помеченный `[ASSUMPTION_DATA_SEED]`.

### 3.2 Инструмент‑контур
- `tools/check_sins` — детектор недетерминизма/float/REAL.  
- `tools/validate_pack` — fail‑fast валидация по канону (B21/B24/B18/B20/B22 + общие).  
- `tools/build_pack` — сборка runtime `content.db` + `pack_manifest.json` + `build_report.json`.  
- `tools/coverage_report` — генерация `docs/COVERAGE_REPORT.md` из ledger.  
- `tools/ci` — одна команда: sins→validate→build→repro→client smoke→determinism→coverage.

### 3.3 Клиент‑контур
Минимальный .NET 8 C# console клиент с командами:
`new-run, craft, go-poi, open-poi, accept-quest, submit-quest, show-*, replay-script, determinism-check`

### 3.4 Финальный DoD
- `tools/ci` зелёный  
- build reproducible (SHA256(content.db) совпадает)  
- validate ловит нарушения B21/B24/B18/B20/B22 до рантайма  
- клиент проходит MVP цикл  
- determinism harness зелёный  
- coverage gate удовлетворён (см. §6)

---

## 4) ЖЁСТКИЕ ИНВАРИАНТЫ (I01…I48)

### 4.1 Детерминизм и вычисления
- **I01** Client computes all  
- **I02** Fixed‑point only: bp/ChanceBp = int  
- **I03** No float anywhere: код/DDL/JSON (см. check_sins)  
- **I04** Keyed RNG only  
- **I05** No entropy sources (DateTime.Now/Guid/New Random/таймеры)  
- **I06** Stable ordering everywhere  
- **I07** SLOT_TABLE порядок слотов семантический (НЕ сортировать pools)

### 4.2 Контент и выдача
- **I08** item_grant только через LOOT_OPEN(coffer_id)  
- **I09** гарантированная выдача = coffer(1 row)  
- **I10** архивные/элит‑награды не содержат валюту/денежные суррогаты (по канону + валидаторы)

### 4.3 Fail‑closed по умолчанию
- **I11** unknown tag → ERROR  
- **I12** missing ref (item/pool/coffer/quest/poi/tag) → ERROR  
- **I13** missing required mapping source→coffer → ERROR  
- **I14** missing stable ordering key → ERROR  
- **I15** любой обнаруженный float/REAL/NUMERIC/запрещённый API → ERROR

### 4.4 Identity / compatibility / state
- **I16** ID immutable  
- **I17** tag namespaces enforced  
- **I18** aliases (если есть) без циклов, target exists  
- **I19** event‑based idempotency (repeat event_id = no‑op)  
- **I20** canonical JSON serialization  
- **I21** deterministic inst_id / poi_instance_id (no GUID)

### 4.5 MVP‑канон (ключевые блоки)
- **I22** B21 strict (пайки): 3 слота, time_sec ∈ {30,60,120}, HPDelta=0, FoodPoisonChance=0, нет RNG успеха/провала  
- **I23** B24 strict (loot): coffers/pools/row_id/stable ordering/mapping coverage  
- **I24** B18 strict (Архив): objective DELIVER + filter_tags_all, reward via coffer  
- **I25** B20 strict (POI): option требует loot_coffer_id, open‑once  
- **I26** B22 strict (LUCK): бонус‑пулы ограничены по item_class (no equip/weapon/armor)

### 4.6 Evidence discipline + two‑person rule
- **I27** NRWA: нет правила без anchor+цитата+impl+test в ledger  
- **I28** Assumption budget ≤ 20  
- **I29** каждое assumption имеет REVERT PLAN  
- **I30** Coverage gate достигнут до начала клиента (PHASE 5)  
- **I31** Two‑Person Rule применяется к любым изменениям правил/контрактов/валидаторов

### 4.7 Patch‑pack discipline
- **I32** Концепт не редактировать напрямую. Любые правки — только patch pack (idempotent, anchored).

### 4.8 Build/CI discipline
- **I33** check_sins green на каждой фазе  
- **I34** validate green начиная с PHASE 2  
- **I35** build green начиная с PHASE 3  
- **I36** reproducible build обязателен начиная с PHASE 3  
- **I37** determinism harness обязателен на PHASE 6  
- **I38** tools/ci обязателен финально  
- **I39** Golden fixtures для validate/build обязательны

### 4.9 Data normalization discipline (anti‑format drift)
- **I40** Запрещены CSV‑колонки для списков тегов/ссылок (например `tags_csv`). Используй join tables.  
- **I41** JSON‑колонки запрещены для “контентных структур” по умолчанию.  
  - Исключение: event payload / logs, и то **только canonical** serializer + schema guard.  
- **I42** quest `filter_tags_all` хранить нормализованно: join table `quest_objective_filter_tags` (см. §9.2).

### 4.10 Stop conditions
- **I43** При превышении assumption budget — STOP.  
- **I44** При невыполнимости coverage gate после 2 итераций — STOP.  
- **I45** При конфликте канона в B21/B24 — STOP (fail‑closed + [CONFLICT] запись).  
- **I46** Если CI красный после “починки” 2 раза подряд — STOP (обязателен root‑cause отчёт).  
- **I47** Если обнаружен недетерминизм в клиенте после PHASE 5 — rollback и STOP до исправления.  
- **I48** Любая “тихая деградация” (WARN, скрывающий ошибку) запрещена без записи‑разрешения в docs.

---

## 5) ANTI‑HALLUCINATION ПРОТОКОЛ (максимально жёсткий)

### 5.1 NO RULE WITHOUT ANCHOR (NRWA)
Любое правило в DDL/validate/build/client assert обязано иметь запись в `docs/EVIDENCE_LEDGER.md`:

`rule_id | canon_anchor | evidence_excerpt (≤25 words) | impl_ref | test_ref | severity | owner_phase`

- Нет anchor → это `[ASSUMPTION]` и идёт в `docs/GAPS_DECISIONS.md` + REVERT PLAN.

### 5.2 Two‑Person Rule (само‑ревью)
Перед тем как внедрить новое правило/контракт/валидатор:

1) **PROPOSAL**: кратко что и зачем (≤10 строк) + ссылка на canon_anchor.  
2) **COUNTERARGUMENT**: почему это может быть неверно/опасно (≤10 строк), альтернативы.  
3) **DECISION**: выбранный вариант + как тестируем + как откатить.

Запись в `docs/2P_REVIEW_LOG.md` обязательна для изменений правил.

### 5.3 ASSUMPTION_BUDGET=20
- Любой assumption регистрируется в `docs/GAPS_DECISIONS.md` (индекс).  
- При достижении лимита → STOP и “Assumption Reduction Plan”.

### 5.4 CONFLICT PROTOCOL
Если канон двоякий/противоречит:
- `[CONFLICT]` в `docs/GAPS_DECISIONS.md`  
- решение fail‑closed  
- REVERT PLAN  
- coverage report отмечает конфликт

### 5.5 FAIL‑CLOSED матрица (обязательная реализация)
unknown/missing refs/missing mapping/unstable ordering/float/REAL → ERROR

### 5.6 Coverage Gate Report (обязателен)
`docs/COVERAGE_REPORT.md` генерируется автоматически:
- total rules  
- rules per Bxx  
- rules_without_anchor (должно быть 0)  
- unresolved assumptions count  
- conflicts count

**Порог перед PHASE 5:**
- total ≥ 30  
- B24 ≥ 9  
- B21 ≥ 5  
- B18 ≥ 5  
- B20 ≥ 5  
- B22 ≥ 4  
- rules_without_anchor = 0

---

## 6) ТЕХСТЕК (строго)

- .NET 8 C# (tools + client)  
- SQLite: Microsoft.Data.Sqlite  
- Tests: xUnit или встроенный self‑test runner (если xUnit слишком тяжёлый)

**Запрещено:** `float/double/decimal`, `Guid.NewGuid`, `DateTime.Now`, `new Random()`.

---

## 7) СТРУКТУРА РЕПО (каноничная)

```
/
  content/
    authoring/
      modules/
        tags.db
        items.db
        loot.db
        recipes.db
        quests.db
        pois.db
        narratives.db               # PHASE 7 (optional)
    dist/
      <pack_version>/
        content.db
        pack_manifest.json
        build_report.json
        sha256.txt                 # hash gate output
  tools/
    src/
      Tools.sln
      CheckSins/
      CoverageReport/
      ValidatePack/
      BuildPack/
      ApplyPatchPack/              # patch-pack discipline
      Ci/                          # one-command pipeline
    fixtures/
      validate/
        neg_*/                     # negative fixtures
      golden/
        build_expected.json
        validate_expected.json
        content_db_sha256.txt
  client/
    src/
      Client.sln
      GameClient/
    saves/
      save.json
    scripts/
      golden_trace.json
      smoke_play.json
  docs/
    concept/
    templates/
      TEMPLATE_EVIDENCE_LEDGER.md
      TEMPLATE_GAPS_DECISIONS.md
      TEMPLATE_SEED_NOTES.md
      TEMPLATE_COVERAGE_REPORT.md
      TEMPLATE_PATCH_PACK.md
      TEMPLATE_SCHEMA_CONTRACT.md
      TEMPLATE_GOLDEN_TRACE.json
      TEMPLATE_CI.md
    CANON_MAP.md
    ID_POLICY.md
    DATA_BACKLOG.md
    VALIDATION_RULESET.md
    EVIDENCE_LEDGER.md
    2P_REVIEW_LOG.md
    GAPS_DECISIONS.md
    SEED_NOTES.md
    QA_SMOKE.md
    REPRO.md
    COVERAGE_REPORT.md
  README.md
```

---

## 8) КЛЮЧЕВЫЕ КОНТРАКТЫ (референс)

### 8.1 Keyed RNG
```
bytes = UTF8($"{world_seed}|{rng_stream}|{context}|{scope_id}|{draw_index}")
hash  = SHA256(bytes)
u64   = little_endian_u64(hash[0..7])
```

### 8.2 Weighted pick
`sum_w = Σ weight_int`, `r = u64 % sum_w`, rows in stable order, first `acc > r`.

### 8.3 Canonical JSON
keys sorted; arrays stable; no unordered dict serialization.

### 8.4 Event ID / Idempotency
`event_id = SHA256($"{command}|{scope_id}|{step_index}|{payload_canonical_json}")`, repeat → no‑op.

### 8.5 LOOT_OPEN
coffer: `K_PICKS` or `SLOT_TABLE`; LUCK bonus after base; draw_index layout fixed and documented.

---

## 9) DATA MODEL RULES (обязательные решения против дрейфа форматов)

### 9.1 Tags — только нормализация
- `tags(tag_id, namespace, …)` — истина tag_id  
- Любая связь tag с сущностью: join tables (`item_tags`, `poi_tags`, …)

### 9.2 Quest objective filter_tags_all — нормализовано
Запрещено хранить `filter_tags_all_csv` или “произвольный json”.  
Нужно:

- `quest_objectives(quest_id, obj_id, type, qty_required_int, …)`
- `quest_objective_filter_tags(quest_id, obj_id, tag_id)`  
и валидировать: для каждого objective набор tag_id существует и stable order выводится как `tag_id asc`.

### 9.3 Seed‑числа — только в DB + SEED_NOTES
В коде не хардкодить балансы. Любые числа для играбельности — в DB и в `docs/SEED_NOTES.md`.

---

# 10) PHASES (P0–P7) + GATES + DEFINITIONS OF TESTS

> **Правило:** переход к следующей фазе только при зелёных гейтах и выполненном DoD.

## 
---

## ДОПОЛНЕНИЕ v3.6: Local Starter Kit (обязателен в MODE B/C, желателен в MODE A)
Проект должен содержать:
- `dependency_check.ps1/.sh`
- `run_local.ps1/.sh`
- `docs/LOCAL_STARTER.md`
- `docs/EXPECTED_OUTPUTS.md`

В MODE B/C агент обязан:
- генерировать эти файлы
- писать UNVERIFIED
- давать точные команды локального прогона

---

## ДОПОЛНЕНИЕ v3.6: CI LOG CONTRACT
CI должен создавать логи:
- `_logs/ci.log`
- `_logs/check_sins.log`
- `_logs/coverage.log`
- `_logs/validate_seed.log`
- `_logs/validate_neg.log`
- `_logs/build.log`
- `_logs/repro_build.log`
- `_logs/golden_compare.log`
- `_logs/client_smoke.log`
- `_logs/determinism.log`

И артефакты:
- `docs/COVERAGE_REPORT.md`
- `content/dist/<pack_version>/sha256.txt`
- `client/_out/smoke_summary.json` (или .txt)
- `client/_out/determinism_report.json`

---

## ДОПОЛНЕНИЕ v3.6: Phase 0 AUTO-CI override
В PHASE 0 (помимо всего прочего) обязателен выпуск:
- `tools/ci.ps1`, `tools/ci.sh`
- `docs/CI_LOG_LAYOUT.md`
- создание `_logs/` и (MODE A) запуск CI в режиме `probe`.


PHASE 0 — CONCEPT INGEST + SCAFFOLD + TEMPLATE DROP
**Цель:** распаковать концепт, создать структуру, положить шаблоны docs, сделать bootstrap gates.

**Tasks**
- P0.1 распаковать `<CONCEPT_PACK_ZIP>` → `docs/concept/`
- P0.2 создать структуру репо (директории)
- P0.3 скопировать шаблоны из `docs/templates/` (см. пакет шаблонов) в рабочие docs:
  - `EVIDENCE_LEDGER.md`, `GAPS_DECISIONS.md`, `SEED_NOTES.md`, `2P_REVIEW_LOG.md`
- P0.4 создать `docs/CANON_MAP.md` (домен→Bxx anchors) и `docs/ID_POLICY.md`
- P0.5 bootstrap `tools/check_sins` (ps1+sh) + bootstrap `tools/ci` (ps1+sh) *как оболочка*, даже до C# версий

**Gates**
- GATE.SINS(bootstrap): check_sins script PASS

**DoD**
- CANON_MAP включает: Tags/Items/Loot/Recipes/Quests/POI/Luck/RNG/Idempotency  
- must‑have anchors: B21/B24/B18/B20/B22/B14/B03/B04  
- templates размещены, и форматы фиксированы

**Tests**
- POS-P0: команда печатает число найденных `@@BEGIN:B` блоков  
- NEG-P0: добавь строку `Guid.NewGuid` в пустой файл и проверь, что check_sins падает

---

## PHASE 1 — DB SPEC + C# CHECK_SINS + SCHEMA CONTRACTS
**Цель:** создать DB схемы и зафиксировать schema contracts.

**Tasks**
- P1.0 реализовать `tools/src/CheckSins` (C#) и заменить bootstrap вызовы на него
- P1.1 создать DDL и `.db`: tags/items/loot/recipes/quests/pois (нормализованные join tables, без CSV/JSON структур)
- P1.2 создать `docs/schema_contracts/`:
  - `authoring_schema_contract.json` (expected tables/columns/types)
  - `runtime_schema_contract.json` (expected runtime schema)
- P1.3 реализовать `tools/src/SchemaContract` (можно внутри ValidatePack): проверка схемы vs contract
- P1.4 заполнить `docs/DATA_BACKLOG.md` и `docs/VALIDATION_RULESET.md` с canon_anchor для каждой таблицы/правила (или [ASSUMPTION])

**Gates**
- GATE.SINS (C#) PASS  
- GATE.SCHEMA_CONTRACT PASS (authoring)

**DoD**
- нет REAL/NUMERIC в db  
- join tables вместо CSV  
- schema contracts существуют и проверяются

**Tests**
- POS-P1: schema contract PASS  
- NEG-P1: добавить колонку REAL в тестовую db → FAIL (rule_id)

---

## PHASE 2 — VALIDATORS + LEDGER + COVERAGE + GOLDEN FIXTURES (VALIDATE)
**Цель:** validate_pack с negative fixtures, ledger ≥ 30, coverage gate PASS, golden fixtures для validate.

**Tasks**
- P2.0 реализовать `tools/src/CoverageReport` → `docs/COVERAGE_REPORT.md`
- P2.1 реализовать `tools/src/ValidatePack` + schema_contract checks
- P2.2 создать negative fixtures (по доменам; минимум 10)
- P2.3 заполнить `docs/EVIDENCE_LEDGER.md` (≥30) и `docs/2P_REVIEW_LOG.md` для новых правил
- P2.4 создать golden fixtures:
  - `tools/fixtures/golden/validate_expected.json` (детерминированный отчёт validate для seed)
  - validate_pack должен уметь `--emit-report` и `--compare-golden`

**Gates**
- GATE.SINS PASS  
- GATE.VALIDATE PASS (seed)  
- GATE.VALIDATE_NEG FAIL on each fixture  
- GATE.COVERAGE PASS

**DoD**
- coverage gate thresholds выполнены  
- rules_without_anchor = 0  
- validate report стабилен и сравним с golden

---

## PHASE 3 — BUILD PACK + GOLDEN FIXTURES (BUILD) + REPRO HASH
**Цель:** build_pack reproducible + golden build outputs.

**Tasks**
- P3.1 реализовать `tools/src/BuildPack`:
  - load modules → validate → compile runtime content.db
  - write pack_manifest + build_report + sha256.txt
- P3.2 deterministic row_id generation (если допускается каноном) и запись generated_ids_count
- P3.3 golden fixtures:
  - `tools/fixtures/golden/build_expected.json`
  - `tools/fixtures/golden/content_db_sha256.txt`
  - build_pack поддерживает `--emit-report` и `--compare-golden`
- P3.4 reproducible build: build twice → same sha256

**Gates**
- GATE.SINS PASS  
- GATE.VALIDATE PASS  
- GATE.BUILD PASS  
- GATE.REPRO_BUILD PASS  
- GATE.GOLDEN_BUILD PASS

---

## PHASE 4 — SEED CONTENT (строго дисциплинированный) + GOLDEN UPDATE POLICY
**Цель:** минимальный контент для игры, отмеченный, и golden обновляются только при явной процедуре.

**Tasks**
- P4.1 заполнить tags/items/recipes/loot/quests/pois минимально
- P4.2 `docs/SEED_NOTES.md`: все seed‑числа, почему, и revert plan
- P4.3 policy: golden обновления только через `tools/update_golden` (или явный флаг `--accept-golden`), и это логируется в `docs/2P_REVIEW_LOG.md`

**Gates**
- все гейты PHASE 3 + golden validate/build PASS

---

## PHASE 5 — CLIENT MVP + CLIENT GOLDEN SMOKE
**Цель:** играбельный цикл + client smoke golden outputs.

**Tasks**
- P5.1 GameClient load content.db; save/load; keyed RNG; LOOT_OPEN engine
- P5.2 strict runtime asserts: item grants only via LOOT_OPEN
- P5.3 scripts:
  - `client/scripts/smoke_play.json` (MVP loop)
- P5.4 golden client outputs:
  - `client/scripts/smoke_expected.txt` (или json) — детерминированный лог/сводка
  - режим клиента `--run-script --emit-summary` и `--compare-golden`

**Gates**
- GATE.SINS PASS  
- GATE.CLIENT_SMOKE PASS  
- GATE.CLIENT_GOLDEN PASS

---

## PHASE 6 — DETERMINISM HARNESS + GOLDEN TRACE
**Цель:** доказать детерминизм.

**Tasks**
- P6.1 determinism-check: run script twice compare state_hash
- P6.2 `client/scripts/golden_trace.json` + expected hash
- P6.3 docs/REPRO.md

**Gates**
- GATE.DETERMINISM PASS  
- GATE.GOLDEN_TRACE PASS

---

## PHASE 7 — DETERMINISTIC NARRATIVE (optional, but recommended)
**Цель:** “ощущение игры” без хаоса.

**Tasks**
- P7.1 narratives.db + narrative.pick via keyed RNG (scope_id=event_id)
- P7.2 3–5 варианта описаний POI/находок/архива
- P7.3 determinism gate stays green

---

# 11) CI PIPELINE (must exist)
`tools/ci` делает:
1) check_sins  
2) validate_pack (seed + fixtures)  
3) build_pack + repro hash  
4) compare golden validate/build  
5) client smoke script + golden compare  
6) determinism harness + golden trace compare  
7) coverage_report gate

CI должен завершаться non‑zero при любом нарушении.

---

# 12) STOP CONDITIONS (must obey)
Остановиться и вывести root‑cause report если:
- assumption budget exceeded  
- coverage gate unmet after 2 iterations  
- B21/B24 conflict cannot be resolved fail‑closed  
- CI fails twice in a row after attempted fixes  
- nondeterminism detected post‑PHASE5

---

# НАЧИНАЙ
Начинай с PHASE 0 и соблюдай гейты. Никаких прыжков.


---

## ДОПОЛНЕНИЕ v3.7: Attachment/Path Resolution Contract (PHASE -1)
PHASE -1 обязан определить, где физически находится:
- `concept_pack_v0.2.zip` (вложение в чате или путь в FS)
- пакет промта/шаблонов (если приложен отдельным zip)

**Правило:**
- Если доступен терминал/FS listing: перечисли кандидаты (`/mnt/data`, текущая директория, `Downloads/` при наличии) и выбери файл по имени/размеру.
- Если listing невозможен: попроси пользователя заново прикрепить файл и указать имя (без продолжения фазы).

Артефакт:
- `docs/INPUTS_RESOLVED.md`:
  - resolved_concept_zip_path
  - resolved_prompt_zip_path (если применимо)
  - unpack_dest
  - hash/size (если доступно)

---

## ДОПОЛНЕНИЕ v3.7: Phase-aware CI Enforcement (SKIPPED -> ERROR)
Введены переменные окружения/флаги для CI:

- `CI_LEVEL`: `probe` | `full` (по умолчанию `probe` в PHASE 0)
- `PHASE_TARGET`: `0..7` (какая фаза “считается готовой”)

**Правила required-steps по PHASE_TARGET:**
- target >= 0: `check_sins`, `coverage_report` (формат/файл существует)
- target >= 2: `validate_seed`, `validate_neg`, `coverage_gate` (rules/anchors)
- target >= 3: `build_pack`, `repro_build` (sha256 stable)
- target >= 5: `client_smoke` (scripted), `client_golden`
- target >= 6: `determinism` + `golden_trace`
- target >= 6: `golden_compare` (validate/build/client) обязателен
- target >= 5: `coverage_gate` обязателен и должен PASS

Если `CI_LEVEL=full` и шаг required для target, то:
- `SKIPPED` или `UNVERIFIED` = **ERROR** и CI возвращает non-zero.

---

## ДОПОЛНЕНИЕ v3.7: Python Stack Spec (если dotnet недоступен)
Если STACK_PYTHON выбран в PHASE -1, проект обязан иметь:

### Tools (Python)
- `tools/py/check_sins.py` — scans repo for forbidden tokens; scans sqlite schemas for REAL/NUMERIC
- `tools/py/coverage_report.py` — parses `docs/EVIDENCE_LEDGER.md` → `docs/COVERAGE_REPORT.md`
- `tools/py/validate_pack.py` — validates authoring modules (schema/refs + B21/B24/B18/B20/B22 rules)
- `tools/py/build_pack.py` — compile runtime `content.db` + `pack_manifest.json` + `build_report.json` + `sha256.txt`
- `tools/py/apply_patch_pack.py` — applies patch pack idempotently (optional)
- `tools/py/ci.py` — drives CI steps and writes `_logs/*.log` (used by tools/ci.sh/ci.ps1 wrappers)

### Client (Python)
- `client/py/game_client.py` — console client with commands:
  `new-run, craft, go-poi, open-poi, accept-quest, submit-quest, show-*, replay-script, determinism-check`
- SQLite access через стандартный `sqlite3` модуль.
- Никаких float: все bp/chance/qty/weights/int fields — int.
- Keyed RNG: SHA256(...) → u64 → pick.

### Команды локального запуска (Python)
- `python tools/py/check_sins.py`
- `python tools/py/validate_pack.py --modules content/authoring/modules`
- `python tools/py/build_pack.py --modules content/authoring/modules --out content/dist/<ver>`
- `python client/py/game_client.py --db content/dist/<ver>/content.db --run-script client/scripts/smoke_play.json`
- `python client/py/game_client.py --db ... --determinism-check client/scripts/golden_trace.json`

**Важно:** в MODE B/C всё это описывается как UNVERIFIED, но файлы должны быть сгенерированы.

---
