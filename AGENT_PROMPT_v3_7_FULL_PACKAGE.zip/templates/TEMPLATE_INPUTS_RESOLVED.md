# INPUTS_RESOLVED.md (TEMPLATE)
- resolved_concept_zip_path:
- resolved_prompt_zip_path:
- unpack_dest:
- concept_zip_size_bytes:
- concept_zip_sha256:
