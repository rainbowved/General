# LOCAL_STARTER.md
1) dependency_check (Windows: dependency_check.ps1, Linux/mac: dependency_check.sh)
2) run_local (Windows: run_local.ps1, Linux/mac: run_local.sh)
3) See _logs/*.log for first ERROR rule_id.
