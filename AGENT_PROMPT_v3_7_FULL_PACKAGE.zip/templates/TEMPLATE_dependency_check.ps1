$ErrorActionPreference="Stop"
New-Item -ItemType Directory -Force -Path _logs | Out-Null
Start-Transcript -Path "_logs\dependency_check.log" -Force | Out-Null
Write-Host "== Dependency Check =="
function Have($cmd){ (Get-Command $cmd -ErrorAction SilentlyContinue) -ne $null }
if (Have "dotnet"){ Write-Host "[OK] dotnet:" (dotnet --version) } else { Write-Host "[MISS] dotnet" }
if (Have "python"){ Write-Host "[OK] python:" (python --version) }
elseif (Have "python3"){ Write-Host "[OK] python3:" (python3 --version) } else { Write-Host "[MISS] python/python3" }
if (Have "sqlite3"){ Write-Host "[OK] sqlite3:" (sqlite3 --version) } else { Write-Host "[MISS] sqlite3 (optional)" }
if (Have "git"){ Write-Host "[OK] git:" (git --version) } else { Write-Host "[MISS] git (optional)" }
Write-Host "== Done =="
Stop-Transcript | Out-Null
