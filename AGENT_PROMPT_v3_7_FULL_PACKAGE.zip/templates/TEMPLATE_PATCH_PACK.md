# PATCH_PACK.md (TEMPLATE)
> Любые правки концепта/доков канона — только patch pack.
> Требования: anchored, idempotent, minimal, reversible.

## Patch 001
- target_file: docs/concept/CONCEPT_OPTIMIZED_v3.md
- anchor_begin: "@@BEGIN:B24@@"
- anchor_end: "@@END:B24@@"
- find_regex: ""
- replace_text: ""
- idempotency_note: "Applying twice yields same file"
- rationale:
- tests_to_update:
