# COVERAGE_REPORT.md (TEMPLATE)
> Генерируется tools/coverage_report. Ручные правки запрещены.

## Summary
- total_rules:
- rules_without_anchor:
- assumptions_count:
- conflicts_count:

## Coverage by Anchor (Bxx)
| anchor | rule_count |
|---|---|
| B24 | 0 |
| B21 | 0 |
| B18 | 0 |
| B20 | 0 |
| B22 | 0 |

## Gate
- gate_pass: false
- unmet_requirements:
