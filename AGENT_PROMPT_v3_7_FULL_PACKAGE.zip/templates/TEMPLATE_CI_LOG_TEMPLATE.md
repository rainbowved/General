# CI_LOG_TEMPLATE.md
[STEP] <name>
[CMD]  <command line>
[STATUS] OK | ERROR | SKIPPED | UNVERIFIED
[LOG]  <path to log file>
