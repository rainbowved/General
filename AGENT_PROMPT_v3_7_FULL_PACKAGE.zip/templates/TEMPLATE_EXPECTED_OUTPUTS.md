# EXPECTED_OUTPUTS.md
After successful full CI:
- content/dist/<pack_version>/content.db + sha256.txt
- docs/COVERAGE_REPORT.md (gate_pass=true)
- client/_out/* summaries
- _logs/*.log
