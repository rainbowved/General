# CI.md (TEMPLATE)
## One-command CI
CI must run:
1) tools/check_sins
2) tools/validate_pack (seed)
3) tools/validate_pack (neg fixtures)
4) tools/build_pack
5) repro build hash compare
6) compare golden validate/build outputs
7) client smoke script + golden compare
8) determinism harness + golden trace
9) coverage gate

Exit code non-zero if any step fails.
