$ErrorActionPreference="Stop"
New-Item -ItemType Directory -Force -Path _logs | Out-Null
Start-Transcript -Path "_logs\ci.log" -Force | Out-Null
Write-Host "== Local CI =="
try { & .\dependency_check.ps1 } catch { Write-Host "[WARN] dependency_check failed:" $_ }
& .\tools\ci.ps1
Write-Host "== Done =="
Stop-Transcript | Out-Null
