# SCHEMA_CONTRACT.md (TEMPLATE)
> Контракт схемы. Генерируется один раз и затем проверяется тестами.
> Любая смена — через 2P review + CI green + (если нужно) migration plan.

## Authoring DBs
- tags.db:
  - tables:
    - tags(tag_id TEXT PK, namespace TEXT, descr_ru TEXT, flags_int INT)
    - subsystem_tag_allowlist(subsystem_id TEXT, namespace TEXT)
- items.db:
  - tables:
    - items(...)
    - item_tags(...)
    - item_food_effects(...)
...
