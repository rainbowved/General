#!/usr/bin/env bash
set -euo pipefail
mkdir -p _logs
exec > >(tee _logs/dependency_check.log) 2>&1
echo "== Dependency Check =="
have() { command -v "$1" >/dev/null 2>&1; }
if have dotnet; then echo "[OK] dotnet: $(dotnet --version)"; else echo "[MISS] dotnet"; fi
if have python3; then echo "[OK] python3: $(python3 --version)"; elif have python; then echo "[OK] python: $(python --version)"; else echo "[MISS] python"; fi
if have sqlite3; then echo "[OK] sqlite3: $(sqlite3 --version | head -n 1)"; else echo "[MISS] sqlite3 (optional)"; fi
if have git; then echo "[OK] git: $(git --version)"; else echo "[MISS] git (optional)"; fi
echo "== Done =="
