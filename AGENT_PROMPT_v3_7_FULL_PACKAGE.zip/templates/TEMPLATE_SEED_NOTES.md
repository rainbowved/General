# SEED_NOTES.md (TEMPLATE)
> Только для [ASSUMPTION_DATA_SEED]. Любые “выдуманные числа” фиксируются здесь.

## Seed Item/Balance Numbers
### S-001
- Domain:
- What number(s):
- Where stored (db/table/row):
- Why needed for playability:
- Risk:
- Revert plan (how to replace with canon/data later):
