$ErrorActionPreference="Stop"

$CI_LEVEL = if ($env:CI_LEVEL) { $env:CI_LEVEL } else { "probe" }      # probe|full
$PHASE_TARGET = if ($env:PHASE_TARGET) { [int]$env:PHASE_TARGET } else { 0 }  # 0..7

New-Item -ItemType Directory -Force -Path _logs | Out-Null
Start-Transcript -Path "_logs\ci.log" -Force | Out-Null

Write-Host "== CI v3.7 =="
Write-Host "CI_LEVEL=$CI_LEVEL PHASE_TARGET=$PHASE_TARGET"

function StepStatus($step, $status) {
  Write-Host "[STATUS] $step = $status"
  $status | Out-File -Encoding ascii -Force -FilePath ("_logs\\{0}.status" -f $step)
}

function RequireIf($required, $step) {
  if ($required -eq 1 -and $CI_LEVEL -eq "full") {
    $statusFile = "_logs\\{0}.status" -f $step
    if (!(Test-Path $statusFile)) { throw "Missing status file for $step" }
    $st = (Get-Content $statusFile -Raw).Trim()
    if ($st -in @("SKIPPED","UNVERIFIED","MISSING")) { throw "Required step $step is $st (PHASE_TARGET=$PHASE_TARGET)" }
  }
}

function RunStep($step, $cmd, $logFile) {
  Write-Host ""
  Write-Host "[STEP] $step"
  Write-Host "[CMD]  $cmd"
  try {
    Invoke-Expression $cmd *>&1 | Tee-Object -FilePath $logFile
    StepStatus $step "OK"
  } catch {
    StepStatus $step "ERROR"
    Write-Host "[ERROR] Step $step failed. See $logFile"
    throw
  }
}

# required map by PHASE_TARGET
$req_check_sins = 1
$req_coverage_report = 1
$req_validate = 0
$req_build = 0
$req_client = 0
$req_det = 0
$req_golden = 0
$req_cov_gate = 0

if ($PHASE_TARGET -ge 2) { $req_validate=1; $req_cov_gate=1 }
if ($PHASE_TARGET -ge 3) { $req_build=1 }
if ($PHASE_TARGET -ge 5) { $req_client=1; $req_golden=1; $req_cov_gate=1 }
if ($PHASE_TARGET -ge 6) { $req_det=1; $req_golden=1 }

Write-Host "-- Required steps: validate=$req_validate build=$req_build client=$req_client det=$req_det golden=$req_golden coverage_gate=$req_cov_gate"

# check_sins
if (Test-Path "tools\\check_sins.ps1") {
  RunStep "check_sins" ".\\tools\\check_sins.ps1" "_logs\\check_sins.log"
} else {
  StepStatus "check_sins" "MISSING"
}
RequireIf $req_check_sins "check_sins"

# coverage_report
if (Test-Path "tools\\coverage_report.ps1") {
  RunStep "coverage" ".\\tools\\coverage_report.ps1" "_logs\\coverage.log"
} elseif (Test-Path "tools\\coverage_report.py") {
  RunStep "coverage" "python tools\\coverage_report.py" "_logs\\coverage.log"
} else {
  StepStatus "coverage" "SKIPPED"
}
RequireIf $req_coverage_report "coverage"

# validate
if (Test-Path "tools\\validate_pack.ps1") {
  RunStep "validate_seed" ".\\tools\\validate_pack.ps1 -Seed" "_logs\\validate_seed.log"
  RunStep "validate_neg"  ".\\tools\\validate_pack.ps1 -Neg"  "_logs\\validate_neg.log"
} elseif (Test-Path "tools\\validate_pack.py") {
  RunStep "validate_seed" "python tools\\validate_pack.py --seed" "_logs\\validate_seed.log"
  RunStep "validate_neg"  "python tools\\validate_pack.py --neg"  "_logs\\validate_neg.log"
} else {
  StepStatus "validate_seed" "SKIPPED"
  StepStatus "validate_neg" "SKIPPED"
}
RequireIf $req_validate "validate_seed"
RequireIf $req_validate "validate_neg"

# build
if (Test-Path "tools\\build_pack.ps1") {
  RunStep "build" ".\\tools\\build_pack.ps1" "_logs\\build.log"
  RunStep "repro_build" ".\\tools\\build_pack.ps1 -Repro" "_logs\\repro_build.log"
} elseif (Test-Path "tools\\build_pack.py") {
  RunStep "build" "python tools\\build_pack.py" "_logs\\build.log"
  RunStep "repro_build" "python tools\\build_pack.py --repro" "_logs\\repro_build.log"
} else {
  StepStatus "build" "SKIPPED"
  StepStatus "repro_build" "SKIPPED"
}
RequireIf $req_build "build"
RequireIf $req_build "repro_build"

# golden_compare
if (Test-Path "tools\\golden_compare.ps1") {
  RunStep "golden_compare" ".\\tools\\golden_compare.ps1" "_logs\\golden_compare.log"
} elseif (Test-Path "tools\\golden_compare.py") {
  RunStep "golden_compare" "python tools\\golden_compare.py" "_logs\\golden_compare.log"
} else {
  StepStatus "golden_compare" "SKIPPED"
}
RequireIf $req_golden "golden_compare"

# client_smoke
if (Test-Path "client\\run_smoke.ps1") {
  RunStep "client_smoke" ".\\client\\run_smoke.ps1" "_logs\\client_smoke.log"
} elseif (Test-Path "client\\run_smoke.py") {
  RunStep "client_smoke" "python client\\run_smoke.py" "_logs\\client_smoke.log"
} else {
  StepStatus "client_smoke" "SKIPPED"
}
RequireIf $req_client "client_smoke"

# determinism
if (Test-Path "client\\run_determinism.ps1") {
  RunStep "determinism" ".\\client\\run_determinism.ps1" "_logs\\determinism.log"
} elseif (Test-Path "client\\run_determinism.py") {
  RunStep "determinism" "python client\\run_determinism.py" "_logs\\determinism.log"
} else {
  StepStatus "determinism" "SKIPPED"
}
RequireIf $req_det "determinism"

# coverage_gate
if (Test-Path "tools\\coverage_gate.ps1") {
  RunStep "coverage_gate" ".\\tools\\coverage_gate.ps1" "_logs\\coverage_gate.log"
} elseif (Test-Path "tools\\coverage_gate.py") {
  RunStep "coverage_gate" "python tools\\coverage_gate.py" "_logs\\coverage_gate.log"
} else {
  StepStatus "coverage_gate" "SKIPPED"
}
RequireIf $req_cov_gate "coverage_gate"

Write-Host ""
Write-Host "== CI done =="
Stop-Transcript | Out-Null
