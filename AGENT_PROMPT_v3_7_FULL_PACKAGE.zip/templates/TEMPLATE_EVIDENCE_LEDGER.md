# EVIDENCE_LEDGER.md (TEMPLATE)
> NRWA: нет правила без anchor+цитата+impl+test.
>
> Заполняй строки. Не удаляй колонки. Не меняй формат без patch-pack.

| rule_id | canon_anchor | evidence_excerpt (<=25 words) | impl_ref | test_ref | severity | owner_phase |
|---|---|---|---|---|---|---|
| RULE_EXAMPLE_001 | B24.CANON.X | "..." | tools/src/ValidatePack/Rules/LootRules.cs:123 | tools/fixtures/validate/neg_missing_map | ERROR | P2 |
