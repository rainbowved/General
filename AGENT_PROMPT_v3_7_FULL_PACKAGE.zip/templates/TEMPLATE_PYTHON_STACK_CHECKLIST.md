# PYTHON_STACK_CHECKLIST.md
If STACK_PYTHON:
- tools/py/check_sins.py
- tools/py/validate_pack.py
- tools/py/build_pack.py
- tools/py/coverage_report.py
- tools/py/ci.py
- client/py/game_client.py
- tools/ci.ps1 + tools/ci.sh call python tools/py/ci.py when present
