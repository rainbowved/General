#!/usr/bin/env bash
set -euo pipefail
mkdir -p _logs
exec > >(tee _logs/ci.log) 2>&1
echo "== Local CI =="
bash ./dependency_check.sh || true
bash tools/ci.sh
echo "== Done =="
