#!/usr/bin/env bash
set -euo pipefail

CI_LEVEL="${CI_LEVEL:-probe}"          # probe|full
PHASE_TARGET="${PHASE_TARGET:-0}"      # 0..7

mkdir -p _logs
exec > >(tee _logs/ci.log) 2>&1

echo "== CI v3.7 =="
echo "CI_LEVEL=$CI_LEVEL PHASE_TARGET=$PHASE_TARGET"

step_status() {
  local step="$1" status="$2"
  echo "[STATUS] $step = $status"
  echo "$status" > "_logs/${step}.status"
}

require_if() {
  local required="$1" step="$2" status_file="_logs/${step}.status"
  if [ "$required" = "1" ] && [ "$CI_LEVEL" = "full" ]; then
    if [ ! -f "$status_file" ]; then
      echo "[ERROR] Missing status file for $step"
      exit 10
    fi
    local st
    st=$(cat "$status_file" | tr -d '\r\n')
    if [ "$st" = "SKIPPED" ] || [ "$st" = "UNVERIFIED" ] || [ "$st" = "MISSING" ]; then
      echo "[ERROR] Required step $step is $st (PHASE_TARGET=$PHASE_TARGET)"
      exit 11
    fi
  fi
}

# required map by PHASE_TARGET
req_check_sins=1
req_coverage_report=1
req_validate=0
req_build=0
req_client=0
req_det=0
req_golden=0
req_cov_gate=0

if [ "$PHASE_TARGET" -ge 2 ]; then req_validate=1; req_cov_gate=1; fi
if [ "$PHASE_TARGET" -ge 3 ]; then req_build=1; fi
if [ "$PHASE_TARGET" -ge 5 ]; then req_client=1; req_golden=1; req_cov_gate=1; fi
if [ "$PHASE_TARGET" -ge 6 ]; then req_det=1; req_golden=1; fi

echo "-- Required steps: validate=$req_validate build=$req_build client=$req_client det=$req_det golden=$req_golden coverage_gate=$req_cov_gate"

run_step() {
  local step="$1" cmd="$2" log="_logs/${step}.log"
  echo
  echo "[STEP] $step"
  echo "[CMD]  $cmd"
  if eval "$cmd" >"$log" 2>&1; then
    step_status "$step" "OK"
  else
    step_status "$step" "ERROR"
    echo "[ERROR] Step $step failed. See $log"
    exit 2
  fi
}

# 1) check_sins
if [ -f tools/check_sins.sh ]; then
  run_step "check_sins" "bash tools/check_sins.sh"
else
  echo "[STEP] check_sins"
  echo "[WARN] tools/check_sins.sh missing"
  step_status "check_sins" "MISSING"
fi
require_if "$req_check_sins" "check_sins"

# 2) coverage_report
if [ -f tools/coverage_report.sh ]; then
  run_step "coverage" "bash tools/coverage_report.sh"
elif [ -f tools/coverage_report.py ]; then
  run_step "coverage" "python tools/coverage_report.py"
else
  echo "[STEP] coverage"
  echo "[WARN] coverage tool missing"
  step_status "coverage" "SKIPPED"
fi
require_if "$req_coverage_report" "coverage"

# 3) validate_seed + validate_neg
if [ -f tools/validate_pack.sh ]; then
  run_step "validate_seed" "bash tools/validate_pack.sh --seed"
  run_step "validate_neg" "bash tools/validate_pack.sh --neg"
elif [ -f tools/validate_pack.py ]; then
  run_step "validate_seed" "python tools/validate_pack.py --seed"
  run_step "validate_neg" "python tools/validate_pack.py --neg"
else
  echo "[STEP] validate_seed/validate_neg"
  echo "[WARN] validate tool missing"
  step_status "validate_seed" "SKIPPED"
  step_status "validate_neg" "SKIPPED"
fi
require_if "$req_validate" "validate_seed"
require_if "$req_validate" "validate_neg"

# 4) build + repro
if [ -f tools/build_pack.sh ]; then
  run_step "build" "bash tools/build_pack.sh"
  run_step "repro_build" "bash tools/build_pack.sh --repro"
elif [ -f tools/build_pack.py ]; then
  run_step "build" "python tools/build_pack.py"
  run_step "repro_build" "python tools/build_pack.py --repro"
else
  echo "[STEP] build/repro_build"
  echo "[WARN] build tool missing"
  step_status "build" "SKIPPED"
  step_status "repro_build" "SKIPPED"
fi
require_if "$req_build" "build"
require_if "$req_build" "repro_build"

# 5) golden_compare (validate/build/client)
if [ -f tools/golden_compare.sh ]; then
  run_step "golden_compare" "bash tools/golden_compare.sh"
elif [ -f tools/golden_compare.py ]; then
  run_step "golden_compare" "python tools/golden_compare.py"
else
  step_status "golden_compare" "SKIPPED"
fi
require_if "$req_golden" "golden_compare"

# 6) client_smoke
if [ -f client/run_smoke.sh ]; then
  run_step "client_smoke" "bash client/run_smoke.sh"
elif [ -f client/run_smoke.py ]; then
  run_step "client_smoke" "python client/run_smoke.py"
else
  step_status "client_smoke" "SKIPPED"
fi
require_if "$req_client" "client_smoke"

# 7) determinism
if [ -f client/run_determinism.sh ]; then
  run_step "determinism" "bash client/run_determinism.sh"
elif [ -f client/run_determinism.py ]; then
  run_step "determinism" "python client/run_determinism.py"
else
  step_status "determinism" "SKIPPED"
fi
require_if "$req_det" "determinism"

# 8) coverage_gate assert
if [ -f tools/coverage_gate.sh ]; then
  run_step "coverage_gate" "bash tools/coverage_gate.sh"
elif [ -f tools/coverage_gate.py ]; then
  run_step "coverage_gate" "python tools/coverage_gate.py"
else
  step_status "coverage_gate" "SKIPPED"
fi
require_if "$req_cov_gate" "coverage_gate"

echo
echo "== CI done =="
