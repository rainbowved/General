-- Bestiary DB schema (v9)
PRAGMA foreign_keys=ON;

CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS monsters (
  monster_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  region TEXT NOT NULL,
  rank TEXT NOT NULL,
  spawn_band TEXT NOT NULL,
  json TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_monsters_region_band_rank ON monsters(region, spawn_band, rank);

CREATE TABLE IF NOT EXISTS attacks (
  monster_id TEXT NOT NULL,
  attack_id TEXT NOT NULL,
  range_m INTEGER NOT NULL,
  attack_profile TEXT NOT NULL,
  weapon_damage_base INTEGER NOT NULL,
  scaling_stat TEXT NOT NULL,
  json TEXT NOT NULL,
  PRIMARY KEY(monster_id, attack_id),
  FOREIGN KEY(monster_id) REFERENCES monsters(monster_id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_attacks_profile ON attacks(attack_profile);
