"""Migration step 0.1 -> 0.2

Normalize inventory ItemInstances:
- ensure instance_id
- ensure qty>=1
- ensure def_id mirror
- ensure location presence (best-effort)

This step is SAFE and reversible: it only fills missing optional fields.
"""

from __future__ import annotations

import copy
import secrets
from typing import Any, Dict


def _gen_ins_id() -> str:
    return "INS_" + secrets.token_hex(5).upper()


def migrate(bundle: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(bundle)
    inv = out.get('inventory') or {}
    items = inv.get('items')
    if not isinstance(items, list):
        return out

    # choose default container
    default_container_id = None
    conts = inv.get('containers')
    if isinstance(conts, list) and conts:
        c0 = conts[0]
        if isinstance(c0, dict):
            default_container_id = c0.get('container_id')
    default_container_id = default_container_id or 'BAG_MAIN'

    for it in items:
        if not isinstance(it, dict):
            continue
        if not it.get('instance_id'):
            it['instance_id'] = _gen_ins_id()
        if 'qty' not in it or it['qty'] is None:
            it['qty'] = 1
        if isinstance(it.get('qty'), int) and it['qty'] <= 0:
            it['qty'] = 1
        # def_id mirror
        if not it.get('def_id') and it.get('item_id'):
            it['def_id'] = it['item_id']
        # location
        if not it.get('location'):
            it['location'] = {'where': 'inventory', 'container_id': default_container_id}
        else:
            loc = it['location']
            if isinstance(loc, dict):
                loc.setdefault('where', 'inventory')
                if loc.get('where') == 'inventory':
                    loc.setdefault('container_id', default_container_id)

    return out
