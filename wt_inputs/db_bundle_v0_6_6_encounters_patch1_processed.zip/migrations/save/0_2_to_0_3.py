"""Migration step 0.2 -> 0.3

Bootstrap RNG state if missing, using Stage4 seed_policy (sha256 derivation).
- Adds rng_state v2 to save/world.json
- Adds rng_state v2 to session/session.json (if session exists)

Does NOT change gameplay, only adds deterministic infrastructure.
"""

from __future__ import annotations

import copy
import hashlib
from datetime import datetime, timezone
from typing import Any, Dict, Optional


def _sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode('utf-8')).hexdigest()


def _derive(seed: str, *parts: str) -> str:
    return _sha256_hex('|'.join([seed, *parts]))


def _now_z() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def migrate(bundle: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(bundle)

    world = out.get('world') or {}
    save_id = world.get('save_id') or out.get('player', {}).get('save_id') or out.get('inventory', {}).get('save_id')
    created_ts = world.get('created_ts') or out.get('player', {}).get('created_ts') or _now_z()

    world_obj = world.get('world') or {}
    world_seed = world_obj.get('world_seed') or f"WSEED_{_sha256_hex(str(save_id))[:12].upper()}"

    # core streams are not required here; we just set known Stage4 streams.
    default_streams = ['RNG_COMBAT','RNG_INJURY','RNG_LOOT','RNG_CRAFT','RNG_SPAWN','RNG_VENDOR','RNG_ECONOMY']

    if not world.get('rng_state'):
        run_seed = _derive(str(world_seed), str(save_id), str(created_ts))
        streams_state = {sid: {'counter': 0} for sid in default_streams}
        world['rng_state'] = {
            'engine': 'pcg32',
            'seeds': {
                'world_seed': world_seed,
                'run_seed': run_seed,
                'session_seed': None,
            },
            'streams_state': streams_state,
            'version': 2,
        }
        out['world'] = world

    # session
    sess = out.get('session')
    if isinstance(sess, dict) and not sess.get('rng_state'):
        session_id = sess.get('session_id') or 'SESSION_UNKNOWN'
        session_started_ts = sess.get('created_ts') or _now_z()
        run_seed = world.get('rng_state', {}).get('seeds', {}).get('run_seed')
        if not run_seed:
            run_seed = _derive(str(world_seed), str(save_id), str(created_ts))
        session_seed = _derive(str(run_seed), str(session_id), str(session_started_ts))
        streams_state = {sid: {'counter': 0} for sid in default_streams}
        sess['rng_state'] = {
            'engine': 'pcg32',
            'seeds': {
                'world_seed': world_seed,
                'run_seed': run_seed,
                'session_seed': session_seed,
            },
            'streams_state': streams_state,
            'version': 2,
        }
        out['session'] = sess

    return out
