"""Migration registry for save bundles."""

from __future__ import annotations

from dataclasses import dataclass
from importlib import import_module
from typing import Any, Dict, List


@dataclass(frozen=True)
class Step:
    id: str
    from_v: str
    to_v: str
    module: str
    description: str


PLAN_ID = "save_bundle_migrations.v0"

STEPS: List[Step] = [
    Step(
        id="MIG_SAVE_0_1_TO_0_2",
        from_v="0.1",
        to_v="0.2",
        module="migrations.save.0_1_to_0_2",
        description="Normalize inventory ItemInstances (instance_id/qty/def_id/location).",
    ),
    Step(
        id="MIG_SAVE_0_2_TO_0_3",
        from_v="0.2",
        to_v="0.3",
        module="migrations.save.0_2_to_0_3",
        description="Bootstrap deterministic rng_state in world (+ session).",
    ),
    Step(
        id="MIG_SAVE_0_3_TO_0_4",
        from_v="0.3",
        to_v="0.4",
        module="migrations.save.0_3_to_0_4",
        description="Fill missing schema_version/pack_version across files.",
    ),
]


def apply_steps(bundle: Dict[str, Any], *, to_version: str = "0.4") -> (Dict[str, Any], List[Dict[str, Any]]):
    """Apply steps sequentially up to to_version (inclusive).

    Returns (new_bundle, applied_steps_log).
    """
    out = bundle
    log: List[Dict[str, Any]] = []

    for s in STEPS:
        mod = import_module(s.module)
        out2 = mod.migrate(out)
        out = out2
        log.append({
            'id': s.id,
            'from': s.from_v,
            'to': s.to_v,
            'module': s.module,
            'description': s.description,
        })
        if s.to_v == to_version:
            break

    return out, log
