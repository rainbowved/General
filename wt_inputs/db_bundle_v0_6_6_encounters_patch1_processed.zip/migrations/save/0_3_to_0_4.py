"""Migration step 0.3 -> 0.4

Align schema_version/pack_version fields across save files when missing.
Rule:
- If field is missing in a file, copy the most common value from other files.
- If values differ, we DO NOT overwrite (only warn in report at the tool level).

Reversible: only fills missing fields.
"""

from __future__ import annotations

import copy
from collections import Counter
from typing import Any, Dict


def migrate(bundle: Dict[str, Any]) -> Dict[str, Any]:
    out = copy.deepcopy(bundle)

    files = [k for k in ['player','world','inventory','progress'] if isinstance(out.get(k), dict)]
    def _most_common(field: str):
        vals = [out[k].get(field) for k in files if out[k].get(field)]
        if not vals:
            return None
        return Counter(vals).most_common(1)[0][0]

    sv = _most_common('schema_version')
    pv = _most_common('pack_version')

    for k in files:
        if sv and not out[k].get('schema_version'):
            out[k]['schema_version'] = sv
        if pv and not out[k].get('pack_version'):
            out[k]['pack_version'] = pv

    return out
