# REPORT_STAGE7_WEIGHTS

- schema_version (db): 0.6.4-db3-econ1-stage7-weights

- patched_at_utc: 2026-02-16T15:10:36Z

- items total: 605

- weights filled: 605 (was missing: 605)


## Статистика по типам (new_weight)

| type         |   count |   min |   median |   max |
|:-------------|--------:|------:|---------:|------:|
| JEWELRY      |     175 |     8 |     13   |    29 |
| ARMOR        |     140 |   200 |   1272   | 13800 |
| COMPONENT    |      50 |     5 |    100   |  2500 |
| WEAPON       |      50 |   600 |   1547.5 |  3680 |
| POTION       |      32 |   150 |    150   |   150 |
| INGREDIENT   |      30 |     5 |    110   |   300 |
| ALCH_RAW     |      30 |    12 |     35   |    90 |
| DISH         |      18 |   300 |    500   |   750 |
| COFFER       |      17 |   300 |    300   |   300 |
| LEG_CORE     |      13 |   300 |    300   |   300 |
| ALCH_REAGENT |      10 |    15 |     48   |    80 |
| LEG_MATERIAL |       8 |    30 |    225   |  1500 |
| SERUM        |       7 |   200 |    200   |   200 |
| STATION      |       6 |  8000 |  45000   | 80000 |
| TOOL         |       6 |    40 |    850   |  1500 |
| CONTAINER    |       5 |   150 |    450   |   550 |
| SHIELD       |       5 |  3500 |   3710   |  4025 |
| SPECIAL      |       2 |     5 |      5   |     5 |
| AMMO         |       1 |    25 |     25   |    25 |


## Примечания

- Единицы веса: граммы, целые числа.

- stackable=1 → заполнен weight_g_per_unit, weight_g = NULL.

- stackable=0 → заполнен weight_g, weight_g_per_unit = NULL.

- Ёмкости контейнеров: использованы существующие поля в extra_json (capacity_ml/capacity_units).



## Таблица изменений (первые 50 строк)

Полный список в `REPORT_STAGE7_WEIGHTS.csv`.


| item_id                           | name_ru                               | type         |   stackable | old_weight   |   new_weight | old_capacity   | new_capacity   | rationale                      |
|:----------------------------------|:--------------------------------------|:-------------|------------:|:-------------|-------------:|:---------------|:---------------|:-------------------------------|
| RAW_ALCH_BLOODROOT                | Кровокорень                           | ALCH_RAW     |           1 |              |           30 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SUNFLOWER                | Солнечный цвет                        | ALCH_RAW     |           1 |              |           15 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_BITTER_BARK              | Горькая кора                          | ALCH_RAW     |           1 |              |           25 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_LIST_ZHIVITSY            | Лист живицы                           | ALCH_RAW     |           1 |              |           12 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SERDTSEVINA_UMNOGO_GRIBA | Сердцевина умного гриба               | ALCH_RAW     |           1 |              |           18 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_PREDATOR_TENDON          | Сухожилие хищника                     | ALCH_RAW     |           1 |              |           35 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_ZHELCH_ZVERYA            | Желчь зверя                           | ALCH_RAW     |           1 |              |           35 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_PAUCHIY_YAD              | Паучий яд                             | ALCH_RAW     |           1 |              |           35 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_PERYA_BYSTROKRYLA        | Перья быстрокрыла                     | ALCH_RAW     |           1 |              |           35 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SALTPETER                | Селитра                               | ALCH_RAW     |           1 |              |           90 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SULFUR                   | Сера                                  | ALCH_RAW     |           1 |              |           90 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_IRONSTONE                | Железняк                              | ALCH_RAW     |           1 |              |           90 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SEREBRYANAYA_STRUZHKA    | Серебряная стружка                    | ALCH_RAW     |           1 |              |           48 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_ECTOPLASM                | Эктоплазма                            | ALCH_RAW     |           1 |              |           60 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_GRAVE_MOSS               | Могильный мох                         | ALCH_RAW     |           1 |              |           12 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_BONE_DUST                | Костная пыль                          | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_GRAVE_DUST               | Могильная пыль                        | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_ASH_BLACK                | Чёрный пепел                          | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_TOMB_SALT                | Склепная соль                         | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_NECRO_WAX                | Некровоск                             | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_ECTO_CORE                | Эктокристалл                          | ALCH_RAW     |           1 |              |           90 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_WRAITH_SHRED             | Клочок савана призрака                | ALCH_RAW     |           1 |              |           50 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_HERB_BITTER              | Горькая трава                         | ALCH_RAW     |           1 |              |           12 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_HERB_SWEET               | Сладкая трава                         | ALCH_RAW     |           1 |              |           12 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_MUSHROOM_COMMON          | Обычный гриб                          | ALCH_RAW     |           1 |              |           18 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SPORE_SACK               | Спора мешочек                         | ALCH_RAW     |           1 |              |           18 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_RESIN_THICK              | Смола густая                          | ALCH_RAW     |           1 |              |           20 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_FLOWER_NIGHT             | Цветок ночной                         | ALCH_RAW     |           1 |              |           15 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_MUSHROOM_RARE            | Гриб редкий                           | ALCH_RAW     |           1 |              |           18 |                |                | alch_raw:keyword_heuristic     |
| RAW_ALCH_SAP_OLDROOT              | Сок древнекорень                      | ALCH_RAW     |           1 |              |           30 |                |                | alch_raw:keyword_heuristic     |
| R1                                | Порошок Кровокорня                    | ALCH_REAGENT |           1 |              |           15 |                |                | alch_reagent:keyword_heuristic |
| R2                                | Настой Солнечного Цвета               | ALCH_REAGENT |           1 |              |           60 |                |                | alch_reagent:keyword_heuristic |
| R3                                | Смола Горькой Коры                    | ALCH_REAGENT |           1 |              |           50 |                |                | alch_reagent:keyword_heuristic |
| R4                                | Экстракт Живицы                       | ALCH_REAGENT |           1 |              |           40 |                |                | alch_reagent:keyword_heuristic |
| R5                                | Зола Жил                              | ALCH_REAGENT |           1 |              |           20 |                |                | alch_reagent:keyword_heuristic |
| R6                                | Масло Лёгкого Шага                    | ALCH_REAGENT |           1 |              |           80 |                |                | alch_reagent:keyword_heuristic |
| R7                                | Дистиллят Мнемы                       | ALCH_REAGENT |           1 |              |           60 |                |                | alch_reagent:keyword_heuristic |
| R8                                | Соль Селитры                          | ALCH_REAGENT |           1 |              |           46 |                |                | alch_reagent:keyword_heuristic |
| R9                                | Взвесь Серы                           | ALCH_REAGENT |           1 |              |           57 |                |                | alch_reagent:keyword_heuristic |
| R10                               | Эссенция Пустоты                      | ALCH_REAGENT |           1 |              |           29 |                |                | alch_reagent:keyword_heuristic |
| POT_HEAL_MINOR                    | Зелье заживления (доступно с начала)  | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_REGEN_MINOR                   | Зелье регенерации (доступно с начала) | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_COAGULANT                     | Коагулянт (стоп кровотечения)         | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_ANTISEPTIC                    | Антисептик (инфекция)                 | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_ANALGESIC                     | Обезболивающее                        | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_DETOX_MINOR                   | Детокс-раствор                        | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_STR_TONIC                     | Тоник силы (базовый)                  | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_DEX_TONIC                     | Настой ловкости (базовый)             | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_INT_TONIC                     | Эликсир интеллекта (базовый)          | POTION       |           1 |              |          150 |                |                | potion:vial                    |
| POT_SPD_SERUM                     | Сыворотка скорости (базовая)          | POTION       |           1 |              |          150 |                |                | potion:vial                    |

## Проверка Stage5 validate
- validate content-db: **FAIL** (DB.BROKEN_REF) — 2 строки в recipe_ingredients ссылаются на несуществующий items.item_id.
- Сверка с исходным db_bundle_v0_6_3: **тот же самый** DB.BROKEN_REF (ошибка была до Stage7), Stage7 её не создавал.
