# Этап 2 — Экземплярность предметов (ItemInstance) + стаки/экипировка/контейнеры (канон данных, v0.1)

**Цель этапа:** перейти от «инвентарь как ItemID+qty» к **инвентарю/экипировке на уровне экземпляров** (ItemInstance), не ломая существующий контент и спеку этапа 1.

Ключевой принцип: **ItemDefinition (из SQLite/JSON паков) не меняем**, добавляем только структуру хранения «экземпляров» в SAVE и операции/события для CHANGELOG.

---

## 1) Решения и допущения (коротко)

- `items.item_id` в SAVE — это **ссылка на ItemDefinition.item_id** из `items` (SQLite). Внутри этапа 2 будем называть это `def_id`, но **в данных оставляем `item_id` как основной ключ** (обратная совместимость).
- `instance_id` **канонически UUID**, но схемы принимают и legacy `INS_*` строки, чтобы не ломать старые сейвы.
- `qty` допускается только `>=1`. Для нестакуемых предметов (`items.stackable=0`) движок должен держать `qty=1`.
- `quality_q` (Q1–Q5) — **optional**, но стандартизирован как `1..5`. Если отсутствует — трактуем как «не задано» (UI/экономика может считать Q2 по умолчанию, если нужно).
- `location` у экземпляра **optional**: если не указан — по умолчанию `inventory/BAG_MAIN`.
- Источник экипировки **канонически** в `save/player.json` (`equipment: slot -> instance_id`). Поле `location.where="equipment"` внутри ItemInstance допустимо как кэш/дублирование.
- Контейнеры делим на 2 уровня:
  1) **логические контейнеры** (`inventory.containers[]`, например `BAG_MAIN`) — уже есть в этапе 1;
  2) **физические контейнеры‑предметы** (в будущем) — тогда используем `location.container_instance_id`.
  На текущем контенте достаточно логических контейнеров.
- CHANGELOG расширяем **только добавлением** новых EventType. Старые `INVENTORY_ADD/REMOVE` остаются валидными.
- Реверс/откат: для операций удаления/слияния рекомендуется хранить `tombstone`/`expect` поля в payload.

---

## 2) Два уровня сущностей

### 2.1 ItemDefinition
**Источник:** SQLite `items` (+ таблицы статов типа `weapon_stats`, `armor_piece_stats`, `potion_stats`, …) и JSON‑паки.

Минимум, который нужен движку этапа 2:
- `item_id` (PK)
- `stackable` (0/1)
- `stack_max` (nullable)
- `tags_json` (для слотов/категорий)

> Никаких правок ItemDefinition на этом этапе.

### 2.2 ItemInstance
**Источник:** SAVE (`save/inventory.json`) и операции CHANGELOG.

Это конкретный экземпляр предмета у игрока/в контейнере/на земле/у торговца.

---

## 3) Канонический формат ItemInstance

Минимальный объект (канон):

```json
{
  "instance_id": "7b8e3d7c-1bcb-4f45-9d5a-2f0b53c6f8f0",
  "item_id": "CMP_CHARCOAL",
  "qty": 12
}
```

Расширенный объект (всё optional кроме трёх полей выше):

```json
{
  "instance_id": "...uuid...",
  "item_id": "...def_id...",
  "def_id": "...optional alias...",
  "qty": 12,
  "quality_q": 2,
  "stack_key": "CMP_CHARCOAL|Q2|B0",
  "location": {
    "where": "inventory",
    "container_id": "BAG_MAIN"
  },
  "flags": {
    "bind_on_pickup": false,
    "bind_on_equip": false,
    "quest_item": false,
    "stolen": false,
    "favorite": false
  },
  "origin": {
    "kind": "SHOP",
    "id": "SHOP_MARKET_GENERAL",
    "ts": "2026-02-16T13:02:36Z"
  },
  "meta": {
    "any_future": "json"
  }
}
```

### 3.1 Поля и смысл
- **instance_id**: UUID (рекомендуется v4). Уникален в рамках сейва.
- **item_id**: ссылка на ItemDefinition (`items.item_id`).
- **qty**: количество в экземпляре.
- **quality_q**: Q1–Q5. Используется для стакинга и (в будущем) для цен/крафта.
- **stack_key**: детерминированный ключ, определяющий «можно ли объединять».
- **location**: где лежит экземпляр (инвентарь/экип/контейнер/земля/торговец).
- **flags**: только метки (без новых механик).
- **origin**: откуда взялся (для логов/проверок/баланса).
- **meta**: свободное поле для будущих расширений.

### 3.2 Ограничение `meta`
- Рекомендуемый лимит: **<= 4 KB** в сериализованном виде на экземпляр.
- Только JSON (без бинарных blob).

---

## 4) Правила стакинга

### 4.1 Источник stackable
- Берём из ItemDefinition (`items.stackable`).
- Если ItemDefinition недоступен/не найден: **не объединяем** автоматически (безопасная деградация).

### 4.2 Условия объединения
Экземпляры можно объединить, если совпадает:
- `item_id`
- `quality_q` (включая оба null)
- bind‑состояние (если используете: напр. `flags.bind_on_pickup` или «уже привязан»)
- `stack_key` (если заполнен)
- дополнительные параметры, влияющие на сущность предмета (если появятся позже: `charges`, `durability`, enchants)

### 4.3 Split (разделение)
- Операция `INVENTORY_STACK_SPLIT`:
  - из исходного экземпляра вычитаем `qty_out`
  - создаём новый `instance_id` с `qty_out`
  - локация нового — как указано в событии (или копия исходной)

---

## 5) Экипировка

### 5.1 Канон хранения
- **Слоты экипировки** храним в `save/player.json`:
  - `equipment: { "SLOT_...": "instance_id" | null }`

### 5.2 Совместимость слота
- Если у ItemDefinition есть тег `SLOT_*` — он задаёт «родной» слот.
- Если у оружия нет `SLOT_*` (в текущих JSON оружия так и есть) — допускаем экипировку в `SLOT_WEAPON_MAIN/OFF` по `type==WEAPON`.
- Если слоты конфликтуют — движок **может** отклонять, а может допускать с предупреждением (решение UI/engine).

### 5.3 Алиасы слотов
В текущем контенте встречаются расхождения (`SLOT_TORSO` vs `SLOT_BODY`, `SLOT_BOOTS` vs `SLOT_FEET`, …). Рекомендуется держать alias‑мап.
См. `content/core/enums.json`.

---

## 6) Контейнеры и вложенность

### 6.1 Логические контейнеры (уже есть)
`save/inventory.json: containers[]` — список контейнеров. Расширение этапа 2:
- `parent_container_id` (optional): позволяет вложенность логических контейнеров.

### 6.2 Физические контейнеры‑предметы (на будущее)
Если появятся предметы типа «мешок/сундук», можно хранить их как ItemInstance и ссылаться через:
- `location.container_instance_id` у предметов внутри.

### 6.3 Защита от рекурсии
- Рекомендуемая max depth: **3**.
- Валидатор должен ловить циклы (A внутри B, B внутри A).

---

## 7) Минимальные операции и новые EventType

Старые события этапа 1 остаются:
- `INVENTORY_ADD`, `INVENTORY_REMOVE`

Новые (рекомендуемые для движка этапа 2):

1) `INVENTORY_ADD_INSTANCES`
- Добавить заранее описанные экземпляры (с instance_id), при необходимости с локацией.

2) `INVENTORY_REMOVE_INSTANCES`
- Удалить qty у конкретных instance_id.
- Для отката — кладём `tombstone` (минимум: item_id/quality/stack_key/location до удаления).

3) `INVENTORY_MOVE`
- Переместить экземпляр между локациями/контейнерами.
- Для частичного переноса стака используем `qty` + `split_new_instance_id`.

4) `INVENTORY_STACK_SPLIT`
- Явное разделение стака.

5) `INVENTORY_STACK_MERGE`
- Явное объединение двух совместимых стаков.

6) `EQUIPMENT_EQUIP`
- Надеть instance в слот, опционально указывая `swap_out_instance_id`.

7) `EQUIPMENT_UNEQUIP`
- Снять со слота в указанную локацию (или по умолчанию в инвентарь).

Схема CHANGELOG обновлена: `schemas/changelog.schema.json`.

---

## 8) Обновлённые схемы

- `schemas/save_inventory.schema.json` — расширен ItemInstance (location/flags/origin/stack_key) + вложенность контейнеров.
- `schemas/changelog.schema.json` — добавлены EventType и payload‑валидации.

Схемы по‑прежнему без внешних зависимостей, JSON Schema draft‑2020‑12.

---

## 9) Примеры

### 9.1 Стаки + split
- SAVE: `examples/save/inventory_stacks_split.json`
- CHANGELOG: `examples/changelog/changelog_stack_split.json`

### 9.2 Экипировка + swap
- SAVE: `examples/save/player_equip_swap.json`, `examples/save/inventory_equip_swap.json`
- CHANGELOG: `examples/changelog/changelog_equip_swap.json`

### 9.3 Контейнер (логическая вложенность)
- SAVE: `examples/save/inventory_nested_containers.json`
- CHANGELOG: `examples/changelog/changelog_move_to_pouch.json`

---

## 10) Валидация и миграция

### 10.1 Мини‑миграция из «старого инвентаря»
Возможные входные варианты:
1) Уже есть `items[]` и у каждого `instance_id` (как в этапе 1) → просто добавляем поля optional (location/flags/origin/stack_key).
2) `items[]` было как `{ item_id, qty }` без `instance_id` → создаём UUID и получаем ItemInstance.

Алгоритм (без кода):
- Для каждой записи:
  - если нет `instance_id` → сгенерировать UUID.
  - если нет `location` → поставить `{where:"inventory", container_id:"BAG_MAIN"}` (если `BAG_MAIN` отсутствует — создать контейнер по умолчанию).
  - если нет `quality_q` → null.
  - если нет `stack_key` → null (движок может вычислять на лету).
  - перенести `meta.origin` в `origin`, если хочется, **не удаляя** из meta (обратимость).

### 10.2 Инварианты валидатора
- `instance_id` уникален.
- `qty >= 1`.
- Если по ItemDefinition `stackable=0` → `qty==1` (ошибка или автопочинка split на отдельные инстансы).
- Все `equipment[slot]` указывают на существующие instance_id.
- Контейнеры:
  - `parent_container_id` не образует циклы;
  - ссылки `location.container_id` существуют в `containers[]` (или допускаем auto‑create как мягкий режим).
- Для `INVENTORY_STACK_MERGE`: `item_id/quality/stack_key` совместимы.

---

## Файлы в этом паке

- `/SPEC_STAGE2_ITEM_INSTANCES.md`
- `/schemas/*.schema.json`
- `/examples/save/*.json`
- `/examples/changelog/*.json`
- `/content/core/enums.json` (опциональный helper)
