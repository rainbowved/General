# STAGE 3 — Core Canon (/content/core)

Версия: **v0.1**  
Pack: **v0.6.3**  
Schema: **2026-02-16.stage3.v0.1**  
Generated: **2026-02-16T13:36:20+00:00**

## 1) Decisions / допущения (фиксируем “канон” в данные)

1. **/content/core = единственный источник истины** для перечислений (enums), формул (formulas), капов/констант (caps) и таблиц (tables).  
2. **Ничего не ломаем:** существующие SQLite/JSON‑паки не трогаем. Добавляем только новые файлы и алиасы/маппинги.
3. **Stable IDs:** все `canonical_id` — стабильные строки (UPPER_SNAKE_CASE по возможности). UI-подписи идут через `display_name_ru`.
4. **Формулы — не “язык программирования”:** `machine_spec` это маленькая DSL‑структура (ограниченный список `op`) — достаточно, чтобы клиент реализовал вычисление без ручных “магических” мест.
5. **Проценты стакаются аддитивно, потом clamp — там где это уже задано концептом** (например, порезка `EffectiveMaxHP`):  
   `Σpenalties` (аддитивно) → `min(cap)` → применить к базе.
6. **Штрафы скорости экипировки стакаются мультипликативно**, т.е. последовательное умножение на `(1 - p/100)` (в концепте явно сказано “все %‑штрафы перемножаются” для EffectiveSPD).
7. **Алиасы — мост совместимости:** любые значения из БД (например `armor_piece_stats.slot=HEAD`) маппим в канонические ID без изменения БД.

## 2) Структура /content/core

Файлы:

- `content/core/core_manifest.json` — точка входа (версии + sha256 файлов)
- `content/core/enums.json` — перечисления (слоты, теги, типы действий…)
- `content/core/formulas.json` — формулы и их `machine_spec`
- `content/core/caps.json` — капы/лимиты/константы
- `content/core/tables.json` — таблицы/кривые/пороговые значения (опционально)
- `content/core/aliases.json` — маппинги совместимости (RU↔ID, DB↔ID и т.д.)

### core_manifest.json
Минимум, который нужен клиенту при загрузке:
- `schema_version`, `pack_version`, `core_version`
- `files` — относительные пути
- `checksums_sha256` — контроль целостности

## 3) Enums (content/core/enums.json)

Принципы:
- каждый enum = массив объектов `{canonical_id, display_name_ru, ...}`
- расширение enum = **не ломающая** операция
- удаление/переименование canonical_id = **ломающее** (не делаем)

Ключевые enums, которые уже нужны клиенту сейчас:
- `Attributes` (STR/DEX/VIT/INT/SPD/LCK)
- `EquipmentSlots` (UNDER, HELMET, CHEST, …, RING1/RING2)
- `ActionType` (MOVE, ATTACK_MELEE, …)
- `DamageProfile` (как минимум то, что встречается в `weapon_stats.attack_profile`)
- `HitZone` (для будущего расчёта урона по зонам тела)
- `StatusId` (минимальный список, расширяемый)
- `Tags` (берём из items.tags_json + базовые BEAST/UNDEAD/PLANT и т.п.)
- `ItemType/ItemGroup/ItemClass` (значения из БД — как есть, чтобы не ломать маппинг)

## 4) Formulas (content/core/formulas.json)

Каждая формула имеет:
- `human_text` — буквальная формула/правило (человекочитаемо)
- `machine_spec` — структурированный JSON (для движка)
- `inputs/outputs` — подсказки для валидатора/UI (не обязаны быть полными)

### DSL `machine_spec` (минимальный набор)
Поддерживаемые `op` в этой версии:
- `add`, `add3`, `add4`
- `sub`
- `mul`, `mul3`
- `div`
- `floor`
- `min`, `max`
- `sum`
- `clamp_int`
- `chain_percent_mul` (последовательное умножение на штрафы %)
- `if`

Ссылки:
- `{"ref":"NAME"}` — ссылка на вход/константу/промежуточный результат
- `{"const":123}` — константа

## 5) Caps / constants (content/core/caps.json)

Тут лежат числа, которые должны быть “в одном месте”:
- `TickSeconds = 10`
- `MaxActions = 3`
- капы щита (`ShieldBlockChanceCapPct=95`, порезки 80/70)
- кап порезки `EffectiveMaxHP` (80% → минимум 20%)
- лимиты вложенности контейнеров/размера meta (для защиты клиента)

## 6) Tables (content/core/tables.json)

Сюда вынесены:
- пороги стадий (`T1..T5`) в процентах (универсально)
- пороги перевеса `r = CarriedWeight / CarryLimit`
- множители фоновой усталости (броня/перевес/статусы/бой)
- стоимость действий по усталости (FAT за 1 Action = 10 секунд)
- восстановление усталости сном/отдыхом

## 7) Aliases (content/core/aliases.json)

Главная задача — совместимость:
- DB → canonical: `armor_piece_stats.slot: HEAD → HELMET`, `BODY → CHEST`, …
- UI RU → canonical: “Шлем” → `HELMET`, …
- legacy → canonical: если старые строки где-то всплывут, мы их не ломаем, а маппим.

Инварианты:
- нет циклов алиасов
- значение алиаса всегда указывает на существующий `canonical_id` соответствующего enum

## 8) Валидация (что валидатор обязан проверять)

Минимальный набор проверок:
1. `core_manifest.json` проходит schema и checksum совпадает.
2. В `enums.json` внутри каждого enum:
   - `canonical_id` уникальны
3. В `aliases.json`:
   - все значения алиасов существуют в целевом enum
   - отсутствуют alias-циклы
4. В `formulas.json`:
   - `op` только из разрешённого набора
   - все `ref` ссылаются на объявленные inputs/константы/промежуточные поля (минимальная проверка, можно мягкая)

## 9) Примеры использования

См. файлы:
- `examples/core_usage/1_actions_per_tick.json`
- `examples/core_usage/2_effective_max_hp.json`
- `examples/core_usage/3_equip_validation.json`

---

## Примечание по совместимости с Этапами 1–2

Этап 3 **ничего не меняет** в SAVE/SESSION/CHANGELOG и ItemInstance.
Он добавляет “канон в JSON”, чтобы:
- валидатор мог проверять значения (слоты/типы/теги)
- движок мог считать по формуле, а не “как помним”
- UI мог показывать `display_name_ru`, не парся концепт
