# STAGE 5 — Validation + Migration (v0.1)

## Decisions / допущения

- **Не ломаем контент.** Инструменты только читают БД/JSON и пишут новые файлы в output (или делают backup при --inplace).
- **Схемы — JSON Schema draft-2020-12.** Если установлен пакет `jsonschema`, выполняется полная проверка схем; иначе — только инварианты + предупреждение.
- **Валидация делится на 4 цели:** `core`, `save`, `changelog`, `content-db` (+ `all`).
- **Миграции пошаговые, обратимые:** шаги только *добавляют/нормализуют отсутствующие поля* (или исправляют очевидно некорректные значения типа qty<=0 → 1). Исходные файлы не трогаются без бэкапа.

## Структура

- `tools/validate.py` — CLI валидатор
- `tools/migrate_save.py` — CLI мигратор сейвов
- `tools/lib/*.py` — загрузка, schema runner, инварианты, sqlite inspect
- `migrations/save/*.py` — пошаговые миграции (0.1→0.2→0.3→0.4)
- `schemas/*.schema.json` — схемы Stage1–4 + схемы отчётов Stage5
- `examples/validate/*` — хорошие/плохие наборы для самопроверки

## Как запускать

### 1) Validate core

```bash
python tools/validate.py core --core-dir content/core
```

Проверяет:
- `core_manifest.json` по схеме
- sha256 файлов из `checksums_sha256`
- базовые инварианты: дубли canonical_id, циклы алиасов, ссылки формул на cap-ключи

### 2) Validate save bundle

```bash
python tools/validate.py save --save-dir . --core-dir content/core
```

`--save-dir` может указывать либо на корень, где лежит `save/` (и опционально `session/`), либо на папку с `player.json/world.json/...` напрямую.

Проверяет:
- schema каждого файла
- инварианты: уникальность `instance_id`, `qty>0`, валидность ссылок экипировки, циклы контейнеров, глубину вложенности (по `caps.ContainerMaxDepth`), базовые RNG-инварианты

### 3) Validate changelog

```bash
python tools/validate.py changelog --file turn_001.json --core-dir content/core
```

Инварианты:
- уникальный `event_id`
- рекомендованная сортировка по `(ts, event_id)`
- RNG: `SYS_RNG_INIT` до `SYS_RNG_ADVANCE`, монотонность `roll_index`, `stream_id` существует в core/rng.json

### 4) Validate content DB

```bash
python tools/validate.py content-db --db rpg_items.sqlite
python tools/validate.py content-db --db rpg_bestiary.sqlite
```

Проверяет таблицы/колонки и «битые ссылки» там, где это возможно (например `loot_pool_items.item_id -> items.item_id`).

### 5) Validate all

```bash
python tools/validate.py all --core-dir content/core --save-dir . --db rpg_items.sqlite --file turn_001.json
```

### Отчёты

Любую команду можно дополнить:
- `--report out.json` — записать отчёт
- `--quiet` — не печатать текст

Формат отчёта описан в `schemas/validate_report.schema.json`.

## Миграции

### Запуск

```bash
python tools/migrate_save.py save --in . --out ./_migrated --to-version 0.4 --core-dir content/core
```

или (опаснее, но с бэкапом):

```bash
python tools/migrate_save.py save --in . --inplace --to-version 0.4
```

После миграции (по умолчанию) автоматически запускается `validate save`.

### Шаги

- `0_1_to_0_2` — нормализация ItemInstance (instance_id/qty/def_id/location)
- `0_2_to_0_3` — bootstrap `rng_state` (Stage4 policy, sha256 derivation)
- `0_3_to_0_4` — заполнение отсутствующих `schema_version/pack_version` единым значением (только если поля пустые)

> Важно: миграции НЕ переименовывают и НЕ удаляют поля; только добавляют то, чего не хватает.

## Версионирование

- `schema_version` — как в Stage1–4 (строка, не обязан быть semver).
- `core_version` — берётся из core/core_manifest.json.
- `to-version` в миграторе — **версия плана миграций** (0.2/0.3/0.4), а не `schema_version`.

## Самопроверка на примерах

```bash
python tools/validate.py core --core-dir examples/validate/core_sample/content/core
python tools/validate.py save --save-dir examples/validate/good_save_bundle --core-dir examples/validate/core_sample/content/core
python tools/validate.py save --save-dir examples/validate/bad_save_bundle --core-dir examples/validate/core_sample/content/core
python tools/validate.py changelog --file examples/validate/good_changelog.json --core-dir examples/validate/core_sample/content/core
python tools/validate.py changelog --file examples/validate/bad_changelog_rng.json --core-dir examples/validate/core_sample/content/core
```

