# STAGE 9 — Encounters + Combat Protocol (Data Layer)

Цель: превратить «встречи» (encounters) в исполняемый слой данных поверх Stage 1–8.

## 1) Что добавлено
- `/content/encounters/encounter_tables.json` — таблицы встреч (weighted entries).
- `/content/encounters/spawn_bands.json` — «банды» (наборы противников) с диапазонами количества.
- `/schemas/encounter_tables.schema.json`, `/schemas/spawn_bands.schema.json` — схемы.
- `/schemas/session.schema.json` — расширение с `active_combat` (optional).
- `/schemas/changelog.schema.json` — расширен боевыми EventType (combat.*) + loot.generate.
- `/tools/validate.py` — добавлена команда `validate encounters` и включение в `validate all`.

## 2) Концепция данных
### EncounterTable
Определяет набор возможных вариантов встречи для региона/тира.
Каждая запись указывает `spawn_band_id` и (опционально) `loot_pool_id`.

### SpawnBand
Определяет состав противников: `monster_id` + `count_min/max`.
Это «шаблон спауна», а конкретный roster (E1/E2/...) формируется клиентом детерминированно.

## 3) Связка с миром (Stage8)
- Узлы world-graph используют `nodes[].links.encounter_table_id` (если задано).
- Если у узла нет `encounter_table_id`, встреча считается «пустой/мирной» на уровне клиента.

## 4) Active combat (session)
- `session.active_combat` хранит ссылки: node_id → encounter_table_id/entry_id/spawn_band_id.
- Не содержит расчётов урона; это контейнер состояния и ссылок.

## 5) CHANGELOG: события боя
Минимальная цепочка:
- `combat.start` → `combat.action_intent` → `combat.action_result` … → `combat.end`
Опционально:
- `system.rng.*` (Stage4) для аудита детерминизма
- `loot.generate` + `INVENTORY_ADD_INSTANCES` для лута

## 6) Валидация
`tools/validate.py encounters` проверяет:
- schema validation encounters файлов
- ссылки `world node → encounter_table_id`
- весовые поля (`weight>0`)
- формат ID

## 7) Примеры
См. `/examples/changelog/combat_flow_min_*.json` и `/examples/session/active_combat_min.json`.
