# STAGE 4 — Deterministic RNG Protocol (seed + streams + roll_index + logs)

Версия спеки: **stage4.v0.1**  
Совместимо с: **Stage 1–3** (SAVE/SESSION/CHANGELOG, ItemInstance, core canon)  
Ограничение: **не трогаем существующие SQLite/JSON-паки**, только добавляем протокол/схемы/примеры.

---

## 1) Decisions / допущения (коротко)

- **Один RNG-движок в core**: `pcg32` (state=64-bit, output=32-bit) — простой и массово реализуемый.
- **Разделяем RNG по потокам (streams)**: бой/лут/травмы/крафт/спавн/вендор и т.д.  
  Это главный механизм “стабильности”: добавление бросков в бою **не двигает** лут, потому что это другой stream.
- **Roll index (counter) ведём отдельно на каждый stream** (uint64, храним как число; при необходимости — как строку в реализации).
- **Логи RNG — через CHANGELOG события**, два режима:
  - **compact**: `SYS_RNG_INIT` + редкие `SYS_RNG_AUDIT_MARK` (чекпоинты)
  - **audit**: плюс `SYS_RNG_ADVANCE` на каждый факт использования RNG
- **Back-compat**: в `save/world.json` допускаем `rng_state` старого вида (v1) и нового (v2) через `oneOf`.
- **Никаких новых игровых механик**: RNG — чисто инфраструктура + формат данных.

---

## 2) RNG engine и почему выбран

`pcg32` даёт детерминизм, простую переносимость и понятную модель состояния.  
Важно: на этом этапе мы фиксируем **протокол** (какие поля и как логируем), а не язык/реализацию.

Файл канона: `content/core/rng.json`.

---

## 3) Streams и routing

### Streams (канон)
- `RNG_COMBAT` — броски боя: hit/damage/crit и т.п. (кроме травм)
- `RNG_INJURY` — травмы/последствия попаданий
- `RNG_LOOT` — лут: weighted choice и т.п.
- `RNG_CRAFT` — крафт/алхимия/кулинария: качество и др. броски, если есть
- `RNG_SPAWN` — энкаунтеры/спавн
- `RNG_VENDOR` — ассортимент вендоров (если появится)
- `RNG_ECONOMY` — редкие экономические случайности (скорее “на будущее”)

### Routing (правило выбора stream)
Используется таблица `routing` в `content/core/rng.json`:  
`"COMBAT_HIT_ROLL" -> "RNG_COMBAT"`, `"LOOT_PICK" -> "RNG_LOOT"` и т.д.

**Запрет “default stream”**: любой вызов RNG обязан указывать `stream_id`.

---

## 4) Формат rng_state (SAVE/SESSION)

### v2 (новый канон)
```json
{
  "engine": "pcg32",
  "mode": "compact",
  "seeds": {
    "world_seed": "WSEED_...",
    "run_seed": "sha256(...)",
    "session_seed": null
  },
  "streams_state": {
    "RNG_COMBAT": { "counter": 120, "state_u64": null, "inc_u64": null },
    "RNG_LOOT":   { "counter": 27 }
  }
}
```

- `counter` = roll_index (монотонно растёт).
- `state_u64/inc_u64` — **опционально**: если клиент хочет быстрый resume без пересчёта state из counter.
  - Для совместимости с JS/SQLite безопаснее хранить u64 как **hex-string** (пример: `"0x1a2b3c"`).

### v1 (legacy, Stage 1–2)
```json
{ "seed": "WSEED_...", "streams": { "combat": { "index": 0 }, "loot": { "index": 0 } } }
```

Клиент может поднять v1 → v2, используя маппинг `legacy.stream_id_map` из `content/core/rng.json`.

---

## 5) CHANGELOG: новые EventType + режимы логирования

### Добавлены EventType (расширение Stage 1–2)
- `SYS_RNG_INIT` (алиас: `system.rng.init`)
- `SYS_RNG_ADVANCE` (алиас: `system.rng.advance`)
- `SYS_RNG_AUDIT_MARK` (алиас: `system.rng.audit_mark`)

> Старый `SYS_RNG_SYNC` остаётся в enum для обратной совместимости, но рекомендуется мигрировать на тройку выше.

### Payload форматы (минимум)

**SYS_RNG_INIT**
- фиксирует engine, mode, и начальные counters по streams (и опционально seeds).

**SYS_RNG_ADVANCE** (audit mode)
- фиксирует факт потребления RNG:
  - `stream_id`
  - `roll_index_before`, `roll_index_after`
  - `roll_kind`
  - `context` (например `"combat.hit_roll"`)
  - `scope_id` (например `"COMBAT_x|ACT_y"`)

**SYS_RNG_AUDIT_MARK** (compact mode)
- контрольная метка после блока событий:
  - `mark_id`
  - counters по streams
  - опционально `checksum_sha256`

### Где ставить audit_mark
Рекомендованные точки (см. `content/core/rng.json` → logging.modes.compact):
- `SYS_TURN_END`
- `COMBAT_END`
- `CRAFT_COMPLETE`

---

## 6) Инварианты / валидация

Технические инварианты (часть в JSON Schema, часть — логикой валидатора):

- `stream_id` должен быть валиден по формату (`^RNG_...`) и **существовать в core/rng.json** (это логика валидатора, не JSON Schema).
- `context` обязателен и не пустой.
- В рамках одного run/save **`SYS_RNG_INIT` должен идти раньше любых advance**.
- `counter` (roll_index) **монотонно растёт** в рамках stream.
- В `SYS_RNG_ADVANCE` ожидается `roll_index_after > roll_index_before` (проверка валидатором).

Схемы:
- `schemas/core_rng.schema.json`
- `schemas/rng_state.schema.json`
- `schemas/changelog.schema.json` (расширена)

---

## 7) Миграция старых сейвов (описание, без кода)

### Если в сейве нет rng_state
1) Берём `world_seed` из `save/world.json`.
2) Выводим `run_seed = sha256(world_seed|save_id|created_ts)`.
3) Инициализируем `streams_state[stream_id].counter = 0` для всех streams из core/rng.json.
4) Пишем `SYS_RNG_INIT` в changelog первого запуска (или при первом `SYS_TURN_BEGIN` после загрузки).

### Если rng_state v1
- Маппим ключи потоков через `legacy.stream_id_map` (combat → RNG_COMBAT и т.д.)
- index → counter
- seed → seeds.world_seed (run/session seeds вычисляем по policy)

---

## 8) Примеры

Смотри:
- `examples/core_usage/rng_usage_1_actions_per_tick_not_rng.json`
- `examples/core_usage/rng_usage_2_loot_weighted_choice.json`
- `examples/core_usage/rng_usage_3_combat_hit_and_injury.json`

CHANGELOG:
- `examples/changelog/changelog_city_compact_rng.json` (compact)
- `examples/changelog/changelog_outwalls_combat_audit_rng.json` (audit)

