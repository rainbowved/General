-- schema dump generated from rpg_items.sqlite
CREATE TABLE armor_piece_stats (
  item_id TEXT PRIMARY KEY,
  armor_set_id TEXT,
  slot TEXT,
  pure_dmg_red_pct INTEGER
);

CREATE TABLE armor_sets (
  set_id TEXT PRIMARY KEY,
  family TEXT NOT NULL,
  tier INTEGER NOT NULL,
  shield_max_pct INTEGER,
  shield_regen_pct INTEGER,
  pure_dmg_red_cap_pct INTEGER,
  stealth_penalty TEXT,
  move_speed_mod_pct INTEGER,
  fatigue_note TEXT,
  perk_text TEXT,
  role TEXT,
  source_paragraph_index INTEGER
);

CREATE TABLE city_factions (
  faction_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  motto TEXT,
  services_json TEXT NOT NULL DEFAULT '[]',
  description TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  extra_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE city_locations (
  loc_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  kind TEXT NOT NULL,
  services_json TEXT NOT NULL DEFAULT '[]',
  description TEXT,
  tags_json TEXT NOT NULL DEFAULT '[]',
  extra_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE city_npcs (
  npc_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  role TEXT NOT NULL,
  faction_id TEXT,
  home_loc_id TEXT,
  services_json TEXT NOT NULL DEFAULT '[]',
  shop_id TEXT,
  quest_board INTEGER NOT NULL DEFAULT 0,
  dialogue_hints TEXT,
  schedule_json TEXT NOT NULL DEFAULT '{}',
  appearance TEXT,
  personality TEXT,
  extra_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE city_quests (
  quest_id TEXT PRIMARY KEY,
  title_ru TEXT NOT NULL,
  giver_npc_id TEXT,
  loc_id TEXT,
  tier_min INTEGER,
  tier_max INTEGER,
  kind TEXT NOT NULL,
  objective_json TEXT NOT NULL DEFAULT '{}',
  rewards_json TEXT NOT NULL DEFAULT '{}',
  prerequisites_json TEXT NOT NULL DEFAULT '[]',
  followups_json TEXT NOT NULL DEFAULT '[]',
  description TEXT,
  lore_text TEXT,
  flags_json TEXT NOT NULL DEFAULT '[]',
  repeatable INTEGER NOT NULL DEFAULT 0
);

CREATE TABLE city_shop_inventory (
  shop_id TEXT NOT NULL,
  item_id TEXT NOT NULL,
  qmin INTEGER NOT NULL DEFAULT 1,
  qmax INTEGER NOT NULL DEFAULT 1,
  stock_min INTEGER NOT NULL DEFAULT 0,
  stock_max INTEGER NOT NULL DEFAULT 0,
  price_base INTEGER NOT NULL DEFAULT 0,
  tags_json TEXT NOT NULL DEFAULT '[]',
  PRIMARY KEY (shop_id, item_id)
);

CREATE TABLE city_shops (
  shop_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  loc_id TEXT NOT NULL,
  npc_id TEXT,
  kind TEXT NOT NULL,
  price_policy_json TEXT NOT NULL DEFAULT '{}',
  restock_json TEXT,
  description TEXT
);

CREATE TABLE cooking_ingredient_stats (
  item_id TEXT PRIMARY KEY,
  HungerDownPct INTEGER,
  ThirstDownPct INTEGER,
  HPDelta INTEGER,
  FoodPoisonChancePct INTEGER
);

CREATE TABLE dish_stats (
  item_id TEXT PRIMARY KEY,
  HungerDownPct INTEGER,
  ThirstDownPct INTEGER,
  HPDelta INTEGER,
  FoodPoisonChancePct INTEGER
);

CREATE TABLE id_aliases (
  alias_id TEXT PRIMARY KEY,
  target_id TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  note TEXT
);

CREATE TABLE items (
  item_id TEXT PRIMARY KEY,
  name_ru TEXT NOT NULL,
  type TEXT NOT NULL,
  "group" TEXT NOT NULL,
  class TEXT NOT NULL,
  tier INTEGER,
  rarity TEXT,
  stackable INTEGER NOT NULL DEFAULT 0,
  stack_max INTEGER,
  weight_g INTEGER,
  weight_g_per_unit INTEGER,
  description TEXT,
  tags_json TEXT,
  obtain_json TEXT,
  extra_json TEXT
);

CREATE TABLE loot_pool_items (
  pool_id TEXT,
  item_id TEXT,
  qmin INTEGER,
  qmax INTEGER,
  qty_min INTEGER,
  qty_max INTEGER,
  weight INTEGER
);

CREATE TABLE loot_pools (
  pool_id TEXT PRIMARY KEY,
  title_ru TEXT,
  qty_note TEXT
);

CREATE TABLE meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
);

CREATE TABLE potion_stats (
  item_id TEXT PRIMARY KEY,
  INTOX INTEGER,
  effect_text TEXT
);

CREATE TABLE recipe_ingredients (
  recipe_id TEXT,
  item_id TEXT,
  qty INTEGER,
  extra_json TEXT
);

CREATE TABLE recipes (
  recipe_id TEXT PRIMARY KEY,
  craft_kind TEXT,
  result_item_id TEXT,
  output_qty INTEGER,
  station_id TEXT,
  tier TEXT,
  extra_json TEXT
);

CREATE TABLE shield_stats (
  item_id TEXT PRIMARY KEY,
  block_melee_chance_pct INTEGER,
  block_ranged_chance_pct INTEGER,
  block_melee_multiplier REAL,
  block_ranged_multiplier REAL,
  move_speed_mod_pct INTEGER,
  stun_chance_pct INTEGER,
  stun_duration_ticks INTEGER
);

CREATE TABLE weapon_stats (
  item_id TEXT PRIMARY KEY,
  weapon_model_id TEXT,
  weapon_name_ru TEXT,
  tier INTEGER,
  weapon_damage_base INTEGER,
  scaling_stat TEXT,
  attack_profile TEXT,
  requires_ammo INTEGER,
  ammo_item_id TEXT
);


-- === ECON PATCH econ1 ===
CREATE TABLE economy_params (
  key TEXT PRIMARY KEY,
  value_json TEXT NOT NULL,
  description TEXT
);

CREATE TABLE item_price_base (
  item_id TEXT PRIMARY KEY,
  price_base_norm INTEGER NOT NULL,
  tier INTEGER,
  rarity TEXT,
  price_base_final_q2 INTEGER,
  name_ru TEXT
);
