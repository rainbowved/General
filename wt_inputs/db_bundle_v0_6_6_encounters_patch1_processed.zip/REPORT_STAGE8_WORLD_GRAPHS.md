# REPORT_STAGE8_WORLD_GRAPHS

Пакет: db_bundle_v0_6_5_world_graphs_patch1  
Дата (UTC): 2026-02-16T15:32:06Z

## Добавлено

- content/world/cityhub_graph.json
- content/world/overwall_graph.json
- content/world/tower_graph.json
- content/world/world_manifest.json
- content/world/aliases_world.json
- schemas/world_graph.schema.json
- schemas/world_manifest.schema.json
- tools/validate.py: новая команда `validate world`

## Статистика графов

- CITYHUB: узлов 15, рёбер 23
- OVERWALL: узлов 56, рёбер 72
- TOWER: узлов 111, рёбер 110

## Привязки (links) к существующему контенту

OVERWALL:
- spawn_band_id: проставлен у 55 узлов (кольца + POI)
- encounter_table_id: проставлен у 55 узлов (кольца -> common pool; POI -> их encounter_pool)
- loot_pool_id: проставлен у 50 POI (первый из списка)
- loot_pool_ids: дополнительно сохранён список у 21 POI, где лут-пулов больше одного

TOWER:
- spawn_band_id: проставлен у 100 этажей (по диапазонам floor_min..floor_max)
- encounter_table_id: проставлен у 100 этажей (обычные -> common pool диапазона; боссы -> boss pool)

CITYHUB:
- links намеренно оставлены пустыми (в city_locations.json нет стабильных ID вендоров/таблиц встреч; добавлено только навигационное ядро: nodes+edges).

## Порталы между графами (world_manifest.json)

- CITYHUB:LOC_CITY_GATE <-> OVERWALL:OW_GATE_OUTSIDE  (CITY_GATE__OVERWALL_GATE)
- CITYHUB:LOC_CITY_TOWERWARD <-> TOWER:TOWER_ENTRANCE (CITY_TOWERWARD__TOWER_ENTRANCE)

## Решения и допущения

1) Для CityHub node_id = loc_id из `json/city_locations.json` (совпадает со стабильными ID).
2) Для Overwall node_id = poi_id из `json/outwalls_poi.json` + добавлены технические хабы `OW_GATE_OUTSIDE` и узлы колец `FOREST_RING_1..5`.
3) Для Tower node_id = `TOWER_F001..TOWER_F100`, отдельные safe-узлы `TOWER_SAFE_010..TOWER_SAFE_100`, и `TOWER_ENTRANCE`.
4) Валидация tower требует: этажи 1..100, рёбра i<->i+1, теги BOSS_FLOOR на 10/20/…/100 и наличие safe-узлов на boss floors.
5) Графы не вводят правил перемещения — только структуру и метаданные для UI/баланса.

## Как проверить

Пример (из корня бандла):

```
python tools/validate.py world --world-dir content/world
```

Подробности: см. docs/specs/SPEC_STAGE5_VALIDATION_MIGRATION.md (валидатор) и SPEC_STAGE1_SAVE_SESSION_CHANGELOG.md (события, в т.ч. WORLD_MOVE).
