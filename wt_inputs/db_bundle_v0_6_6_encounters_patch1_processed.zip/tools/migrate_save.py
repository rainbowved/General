#!/usr/bin/env python3
"""Stage5 save bundle migration CLI.

This tool never modifies input in-place by default.

Examples:
  python tools/migrate_save.py save --in save/ --out save_migrated/ --to-version 0.4 --core-dir content/core
  python tools/migrate_save.py save --in save/ --inplace --to-version 0.4
"""

from __future__ import annotations

import sys
from pathlib import Path as _Path
# ensure project root is importable when running as a script
sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

import argparse
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.lib.loader import LoadError, dump_json, read_save_bundle
from migrations.save.registry import apply_steps

# Reuse validator to auto-validate after migration
import tools.validate as validate_mod

TOOL_VERSION = "stage5.v0.1"


def now_z() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def ensure_backup_inplace(save_dir: Path) -> Path:
    ts = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S')
    backup = save_dir.with_name(save_dir.name + f'.bak_{ts}')
    if backup.exists():
        raise RuntimeError(f"Backup уже существует: {backup}")
    shutil.copytree(save_dir, backup)
    return backup


def write_bundle(out_root: Path, bundle: Dict[str, Any]) -> None:
    # keep layout save/ + session/
    save_dir = out_root / 'save'
    sess_dir = out_root / 'session'
    save_dir.mkdir(parents=True, exist_ok=True)
    sess_dir.mkdir(parents=True, exist_ok=True)

    dump_json(save_dir / 'player.json', bundle['player'])
    dump_json(save_dir / 'world.json', bundle['world'])
    dump_json(save_dir / 'inventory.json', bundle['inventory'])
    dump_json(save_dir / 'progress.json', bundle['progress'])

    if bundle.get('session') is not None:
        dump_json(sess_dir / 'session.json', bundle['session'])


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog='migrate_save', description='Migrate save bundles step-by-step')
    sub = ap.add_subparsers(dest='cmd', required=True)

    p = sub.add_parser('save')
    p.add_argument('--in', dest='in_dir', required=True, help='Папка с save bundle (или root с save/ и session/)')
    p.add_argument('--out', dest='out_dir', default=None, help='Куда писать результат (по умолчанию: <in>_migrated)')
    p.add_argument('--inplace', action='store_true', help='Мигрировать на месте (НЕ по умолчанию). Делает .bak копию.')
    p.add_argument('--to-version', default='0.4', help='Целевая версия миграционного плана (0.2/0.3/0.4).')
    p.add_argument('--core-dir', default=None, help='Если указано — после миграции выполнит validate save с core.')
    p.add_argument('--schemas-dir', default=str(Path(__file__).resolve().parents[1] / 'schemas'))
    p.add_argument('--no-validate', action='store_true', help='Не запускать validate после миграции.')
    p.add_argument('--report', default=None, help='Файл отчёта миграции (JSON).')

    args = ap.parse_args(argv)

    in_root = Path(args.in_dir).resolve()
    out_root = Path(args.out_dir).resolve() if args.out_dir else in_root.with_name(in_root.name + '_migrated')

    if args.inplace:
        backup = ensure_backup_inplace(in_root)
        out_root = in_root
    else:
        backup = None
        if out_root.exists():
            raise SystemExit(f"Выходная папка уже существует: {out_root}")

    try:
        bundle = read_save_bundle(in_root)
    except LoadError as e:
        raise SystemExit(f"Не удалось прочитать save bundle: {e}")

    migrated, applied = apply_steps(bundle, to_version=args.to_version)

    if not args.inplace:
        out_root.mkdir(parents=True, exist_ok=True)
    write_bundle(out_root, migrated)

    # validate
    validate_report = None
    if not args.no_validate:
        validate_report = validate_mod.validate_save(argparse.Namespace(
            save_dir=str(out_root),
            core_dir=args.core_dir,
            schemas_dir=args.schemas_dir,
        ))

    report = {
        'ok': True if (validate_report is None or validate_report.get('ok')) else False,
        'run_at': now_z(),
        'tool_version': TOOL_VERSION,
        'input': str(in_root),
        'output': str(out_root),
        'backup': str(backup) if backup else None,
        'to_version': args.to_version,
        'applied_steps': applied,
        'validate_report': validate_report,
    }

    if args.report:
        from tools.lib.loader import dump_json
        dump_json(Path(args.report), report)

    # human output
    print(f"[MIGRATE] applied_steps={len(applied)} output={out_root}")
    if backup:
        print(f"  backup={backup}")
    if validate_report is not None:
        head = 'OK' if validate_report.get('ok') else 'FAILED'
        print(f"[VALIDATE AFTER MIGRATE] {head} errors={validate_report['stats']['errors']} warnings={validate_report['stats']['warnings']}")

    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())
