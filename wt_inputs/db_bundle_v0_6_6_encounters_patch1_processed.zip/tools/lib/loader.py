"""JSON loading/saving helpers with human-friendly errors."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional, Tuple


class LoadError(Exception):
    pass


@dataclass
class JsonFile:
    path: Path
    data: Any


def load_json(path: Path) -> Any:
    """Load JSON and raise LoadError with context."""
    try:
        text = path.read_text(encoding="utf-8")
    except FileNotFoundError as e:
        raise LoadError(f"Файл не найден: {path}") from e
    except Exception as e:
        raise LoadError(f"Не удалось прочитать файл: {path}: {e}") from e

    try:
        return json.loads(text)
    except json.JSONDecodeError as e:
        # show caret-ish location
        loc = f"строка {e.lineno}, столбец {e.colno}"
        raise LoadError(f"JSON синтаксис ошибка в {path} ({loc}): {e.msg}") from e


def dump_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def find_save_layout(save_dir: Path) -> Tuple[Path, Optional[Path]]:
    """Accept either:
    - <root>/save/player.json ... (+ optional <root>/session/session.json)
    - <root>/player.json ... (+ optional <root>/session.json)

    Returns (save_path, session_path_or_None).
    """
    save_dir = save_dir.resolve()

    # Case 1: nested
    nested = save_dir / "save"
    if (nested / "player.json").exists():
        sess = save_dir / "session" / "session.json"
        return nested, (sess if sess.exists() else None)

    # Case 2: flat
    if (save_dir / "player.json").exists():
        sess = save_dir / "session.json"
        return save_dir, (sess if sess.exists() else None)

    raise LoadError(
        f"Не нашёл save bundle в {save_dir}. Ожидаю player.json/world.json/inventory.json/progress.json "
        "либо прямо в папке, либо в подпапке save/."
    )


def read_save_bundle(save_root: Path) -> Dict[str, Any]:
    save_path, session_path = find_save_layout(save_root)

    bundle: Dict[str, Any] = {}
    for key, fn in [
        ("player", "player.json"),
        ("world", "world.json"),
        ("inventory", "inventory.json"),
        ("progress", "progress.json"),
    ]:
        bundle[key] = load_json(save_path / fn)

    bundle["_paths"] = {
        "save_dir": str(save_path),
        "session": str(session_path) if session_path else None,
    }

    if session_path:
        bundle["session"] = load_json(session_path)
    else:
        bundle["session"] = None

    return bundle
