"""Cross-file invariants for core/save/changelog."""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Set, Tuple

from .schema_runner import Issue
from .hashing import sha256_file


def _sizeof_json(obj: Any) -> int:
    try:
        return len(json.dumps(obj, ensure_ascii=False).encode('utf-8'))
    except Exception:
        return 10**9


def resolve_manifest_path(core_dir: Path, manifest_rel: str) -> Path:
    p = Path(manifest_rel)
    # absolute
    if p.is_absolute() and p.exists():
        return p

    # try relative to core_dir
    cand = core_dir / manifest_rel
    if cand.exists():
        return cand

    # try strip leading content/core/
    s = manifest_rel.replace('\\','/')
    if s.startswith('content/core/'):
        cand2 = core_dir / s[len('content/core/'):]
        if cand2.exists():
            return cand2

    # try basename
    cand3 = core_dir / p.name
    if cand3.exists():
        return cand3

    # try relative to project root = core_dir.parents[1]
    if len(core_dir.parents) >= 2:
        root = core_dir.parents[1]
        cand4 = root / manifest_rel
        if cand4.exists():
            return cand4

    return cand  # best effort


def core_invariants(core_dir: Path, manifest: Dict[str, Any], enums: Optional[Dict[str, Any]] = None, aliases: Optional[Dict[str, Any]] = None, caps: Optional[Dict[str, Any]] = None, formulas: Optional[Dict[str, Any]] = None, rng: Optional[Dict[str, Any]] = None) -> List[Issue]:
    issues: List[Issue] = []

    # checksums
    checks = manifest.get('checksums_sha256', {}) or {}
    for rel, expected in checks.items():
        fp = resolve_manifest_path(core_dir, rel)
        if not fp.exists():
            issues.append(Issue('error','CORE.FILE_MISSING',f'Файл из manifest не найден: {rel}', file=str(fp)))
            continue
        got = sha256_file(fp)
        if expected and got.lower() != str(expected).lower():
            issues.append(Issue('error','CORE.CHECKSUM_MISMATCH',f'SHA256 не совпадает для {rel}: expected={expected} got={got}', file=str(fp)))

    # enums canonical_id uniqueness
    if enums and isinstance(enums.get('enums'), dict):
        for enum_name, arr in enums['enums'].items():
            if not isinstance(arr, list):
                continue
            seen: Set[str] = set()
            for i, it in enumerate(arr):
                cid = (it or {}).get('canonical_id')
                if not cid:
                    continue
                if cid in seen:
                    issues.append(Issue('error','CORE.DUP_CANONICAL_ID',f'{enum_name}: duplicate canonical_id={cid}', path=f'enums.{enum_name}[{i}]', file='enums.json'))
                seen.add(cid)

    # alias cycles: within each mapping dict, detect key->value where value is also a key
    def _scan_map(prefix: str, m: Any):
        if isinstance(m, dict):
            # if all values are scalars, treat as mapping
            if all(not isinstance(v, (dict,list)) for v in m.values()):
                keys = set(m.keys())
                for k, v in m.items():
                    if isinstance(v, str) and v in keys:
                        if v == k:
                            continue  # identity alias is allowed
                        # potential cycle or chain
                        # detect real cycle by walking
                        seen = set([k])
                        cur = v
                        chain = [k, v]
                        while isinstance(cur, str) and cur in m and cur not in seen:
                            seen.add(cur)
                            nxt = m[cur]
                            chain.append(nxt)
                            cur = nxt
                        if cur in seen:
                            issues.append(Issue('error','CORE.ALIAS_CYCLE',f"Alias cycle detected: {' -> '.join(chain[:-1] + [cur])}", path=prefix, file='aliases.json'))
                        seen = set([k])
                        cur = v
                        chain = [k, v]
                        while isinstance(cur, str) and cur in m and cur not in seen:
                            seen.add(cur)
                            nxt = m[cur]
                            chain.append(nxt)
                            cur = nxt
                        if cur in seen:
                            issues.append(Issue('error','CORE.ALIAS_CYCLE',f"Alias cycle detected: {' -> '.join(chain[:-1] + [cur])}", path=prefix, file='aliases.json'))
            else:
                for kk, vv in m.items():
                    _scan_map(f'{prefix}.{kk}' if prefix else kk, vv)

    if aliases:
        _scan_map('aliases', aliases.get('aliases'))

    # formulas refs to caps
    cap_names = set()
    if caps and isinstance(caps.get('caps'), dict):
        cap_names = set(caps['caps'].keys())

    def _scan_refs(node: Any, path: str):
        if isinstance(node, dict):
            if 'ref' in node and isinstance(node['ref'], str):
                r = node['ref']
                # only hard-check if looks like a cap
                if r in {'MaxActions','ContainerMaxDepth','ItemMetaMaxBytes','ItemInstanceMaxQty','Boss_MaxHPDebuffCapPct'}:
                    if r not in cap_names:
                        issues.append(Issue('error','CORE.MISSING_CAP_REF',f'Formula ref {r} отсутствует в caps.caps', path=path, file='formulas.json'))
            for k,v in node.items():
                _scan_refs(v, f'{path}.{k}' if path else k)
        elif isinstance(node, list):
            for i,v in enumerate(node):
                _scan_refs(v, f'{path}[{i}]')

    if formulas and isinstance(formulas.get('formulas'), dict):
        for fname, f in formulas['formulas'].items():
            ms = (f or {}).get('machine_spec')
            if ms is not None:
                _scan_refs(ms, f'formulas.{fname}.machine_spec')

    # rng streams uniqueness
    if rng and isinstance(rng.get('streams'), list):
        sids = [s.get('stream_id') for s in rng['streams'] if isinstance(s, dict)]
        if len(sids) != len(set(sids)):
            issues.append(Issue('error','CORE.DUP_STREAM_ID','rng.streams содержит дубли stream_id', file='rng.json'))

    return issues


def save_invariants(bundle: Dict[str, Any], core_caps: Optional[Dict[str, Any]] = None, core_rng: Optional[Dict[str, Any]] = None) -> List[Issue]:
    issues: List[Issue] = []

    inv = bundle.get('inventory') or {}
    player = bundle.get('player') or {}

    items = inv.get('items') or []
    if not isinstance(items, list):
        return [Issue('error','SAVE.ITEMS_NOT_ARRAY','inventory.items должен быть массивом', file='inventory.json')]

    # unique instance_id
    seen: Set[str] = set()
    by_id: Dict[str, Dict[str, Any]] = {}
    for i,it in enumerate(items):
        iid = (it or {}).get('instance_id')
        if not iid:
            issues.append(Issue('error','SAVE.MISSING_INSTANCE_ID','items[].instance_id обязателен', path=f'items[{i}].instance_id', file='inventory.json'))
            continue
        if iid in seen:
            issues.append(Issue('error','SAVE.DUP_INSTANCE_ID',f'duplicate instance_id={iid}', path=f'items[{i}].instance_id', file='inventory.json'))
        seen.add(iid)
        by_id[iid] = it

        qty = (it or {}).get('qty')
        if isinstance(qty, int) and qty <= 0:
            issues.append(Issue('error','SAVE.ITEM_QTY_INVALID','qty должен быть >= 1', path=f'items[{i}].qty', file='inventory.json', hint='Исправь qty или удали пустой стак.'))
        elif qty is None:
            issues.append(Issue('warning','SAVE.ITEM_QTY_MISSING','qty отсутствует — трактую как 1 (но лучше явно).', path=f'items[{i}]', file='inventory.json'))

        meta = (it or {}).get('meta')
        if meta is not None and core_caps and isinstance(core_caps.get('caps'), dict):
            lim = core_caps['caps'].get('ItemMetaMaxBytes')
            if isinstance(lim, int):
                size = _sizeof_json(meta)
                if size > lim:
                    issues.append(Issue('error','SAVE.META_TOO_LARGE',f'meta слишком большой: {size} bytes > cap {lim}', path=f'items[{i}].meta', file='inventory.json'))

    # equipment refs
    eq = (player.get('equipment') or {})
    if isinstance(eq, dict):
        for slot, iid in eq.items():
            if iid is None:
                continue
            if iid not in by_id:
                issues.append(Issue('error','SAVE.EQUIP_MISSING_INSTANCE',f'equipment[{slot}] ссылается на несуществующий instance_id', path=f'equipment.{slot}', file='player.json', hint='Либо исправь instance_id, либо снимай предмет.'))

    # container nesting + cycles
    # edge: item -> parent_container_instance_id
    parent: Dict[str, str] = {}
    for it in items:
        iid = it.get('instance_id')
        loc = it.get('location') or {}
        if isinstance(loc, dict):
            pid = loc.get('container_instance_id')
            if isinstance(pid, str) and pid:
                parent[iid] = pid

    # cycles
    for start in list(parent.keys()):
        slow = start
        fast = start
        # Floyd cycle detection
        while True:
            slow = parent.get(slow)
            fast = parent.get(parent.get(fast,''), None)
            if slow is None or fast is None:
                break
            if slow == fast:
                # found cycle, reconstruct
                cyc = [slow]
                cur = parent.get(slow)
                while cur and cur != slow and len(cyc) < 20:
                    cyc.append(cur)
                    cur = parent.get(cur)
                cyc.append(slow)
                issues.append(Issue('error','SAVE.CONTAINER_CYCLE',f"Обнаружен цикл контейнеров: {' -> '.join(cyc)}", file='inventory.json', hint='Контейнер не может быть вложен сам в себя через цепочку.'))
                break

    # depth cap
    max_depth = None
    if core_caps and isinstance(core_caps.get('caps'), dict):
        md = core_caps['caps'].get('ContainerMaxDepth')
        if isinstance(md, int):
            max_depth = md

    if max_depth is not None:
        for iid in parent.keys():
            depth = 0
            cur = iid
            seen_local = set()
            while cur in parent:
                cur = parent[cur]
                depth += 1
                if cur in seen_local:
                    break
                seen_local.add(cur)
                if depth > max_depth:
                    issues.append(Issue('error','SAVE.CONTAINER_DEPTH',f'Глубина вложенности {depth} > cap {max_depth} (instance {iid})', file='inventory.json'))
                    break

    # rng_state streams
    if core_rng and isinstance(core_rng.get('streams'), list):
        required_streams = {s.get('stream_id') for s in core_rng['streams'] if isinstance(s, dict) and s.get('stream_id')}
        world = bundle.get('world') or {}
        rng_state = world.get('rng_state')
        if rng_state and isinstance(rng_state, dict):
            streams_state = None
            # v2
            if 'streams_state' in rng_state and isinstance(rng_state['streams_state'], dict):
                streams_state = rng_state['streams_state']
            elif 'streams' in rng_state and isinstance(rng_state['streams'], dict):
                # v1 legacy
                streams_state = {core_rng.get('legacy',{}).get('stream_id_map',{}).get(k,k): v for k,v in rng_state['streams'].items()}
            if streams_state is not None:
                missing = sorted(required_streams - set(streams_state.keys()))
                if missing:
                    issues.append(Issue('warning','SAVE.RNG_MISSING_STREAMS',f'rng_state не содержит stream_id: {", ".join(missing)}', file='world.json', hint='Можно восстановить через миграцию/инициализацию RNG.'))

    return issues


def changelog_invariants(changelog: Dict[str, Any], core_rng: Optional[Dict[str, Any]] = None) -> List[Issue]:
    issues: List[Issue] = []
    events = changelog.get('events')
    if not isinstance(events, list):
        return [Issue('error','CL.EVENTS_NOT_ARRAY','events должен быть массивом', file='changelog.json')]

    # unique event_id
    seen: Set[str] = set()
    for i,ev in enumerate(events):
        eid = (ev or {}).get('event_id')
        if not eid:
            issues.append(Issue('error','CL.MISSING_EVENT_ID','event_id обязателен', path=f'events[{i}].event_id'))
            continue
        if eid in seen:
            issues.append(Issue('error','CL.DUP_EVENT_ID',f'duplicate event_id={eid}', path=f'events[{i}].event_id'))
        seen.add(eid)

    # ordering check (warning): compare with sorted
    def key(ev):
        return (ev.get('ts',''), ev.get('event_id',''))
    sorted_events = sorted(events, key=key)
    if events != sorted_events:
        issues.append(Issue('warning','CL.NOT_SORTED','events не отсортированы по (ts,event_id). Применение должно использовать стабильную сортировку.', hint='Отсортируй при записи или в apply() сортируй перед применением.'))

    # rng rules
    init_seen = False
    last_after: Dict[str, int] = {}

    valid_streams: Optional[Set[str]] = None
    if core_rng and isinstance(core_rng.get('streams'), list):
        valid_streams = {s.get('stream_id') for s in core_rng['streams'] if isinstance(s, dict) and s.get('stream_id')}

    for i,ev in enumerate(events):
        t = ev.get('type')
        payload = ev.get('payload') or {}
        if t == 'SYS_RNG_INIT':
            init_seen = True
        if t == 'SYS_RNG_ADVANCE':
            if not init_seen:
                issues.append(Issue('error','CL.RNG_ADVANCE_BEFORE_INIT','SYS_RNG_ADVANCE встречается до SYS_RNG_INIT', path=f'events[{i}]', hint='В рамках run сначала должен быть init.'))
            sid = payload.get('stream_id')
            if not sid:
                issues.append(Issue('error','CL.RNG_NO_STREAM','SYS_RNG_ADVANCE: stream_id обязателен', path=f'events[{i}].payload.stream_id'))
            else:
                if valid_streams is not None and sid not in valid_streams:
                    issues.append(Issue('error','CL.RNG_UNKNOWN_STREAM',f'stream_id={sid} отсутствует в core/rng.json', path=f'events[{i}].payload.stream_id'))

            before = payload.get('roll_index_before')
            after = payload.get('roll_index_after')
            if isinstance(before, int) and isinstance(after, int):
                if after < before:
                    issues.append(Issue('error','CL.RNG_INDEX_BACKWARD',f'roll_index_after({after}) < roll_index_before({before})', path=f'events[{i}].payload'))
                prev = last_after.get(sid)
                if prev is not None and before < prev:
                    issues.append(Issue('error','CL.RNG_INDEX_NON_MONOTONIC',f'stream {sid}: roll_index_before({before}) < prev_after({prev})', path=f'events[{i}].payload'))
                last_after[sid] = after
            ctx = payload.get('context')
            if not isinstance(ctx, str) or not ctx.strip():
                issues.append(Issue('error','CL.RNG_CONTEXT_EMPTY','SYS_RNG_ADVANCE: context обязателен и не пустой', path=f'events[{i}].payload.context'))

    return issues
