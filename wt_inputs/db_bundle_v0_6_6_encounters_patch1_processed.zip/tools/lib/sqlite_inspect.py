"""SQLite inspection helpers (read-only)."""

from __future__ import annotations

import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Optional, Sequence, Tuple

from .schema_runner import Issue


def open_ro(db_path: Path) -> sqlite3.Connection:
    return sqlite3.connect(f"file:{db_path}?mode=ro", uri=True)


def list_tables(con: sqlite3.Connection) -> List[str]:
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name")
    return [r[0] for r in cur.fetchall()]


def table_columns(con: sqlite3.Connection, table: str) -> List[str]:
    cur = con.cursor()
    cur.execute(f"PRAGMA table_info({table})")
    return [r[1] for r in cur.fetchall()]


def validate_items_db(db_path: Path, *, strict: bool = False) -> List[Issue]:
    issues: List[Issue] = []
    try:
        con = open_ro(db_path)
    except Exception as e:
        return [Issue('error','DB.OPEN_FAILED',f'Не удалось открыть SQLite: {e}', file=str(db_path))]

    with con:
        tables = set(list_tables(con))
        required_min = {'items','meta'}
        missing = sorted(required_min - tables)
        if missing:
            issues.append(Issue('error','DB.MISSING_TABLE',f"Отсутствуют обязательные таблицы: {', '.join(missing)}", file=str(db_path)))
            return issues

        # items columns
        cols = set(table_columns(con,'items'))
        required_cols = {'item_id','name_ru','type','tier','rarity','stackable'}
        miss_cols = sorted(required_cols - cols)
        if miss_cols:
            issues.append(Issue('error','DB.ITEMS_MISSING_COLUMNS',f"items: отсутствуют колонки: {', '.join(miss_cols)}", file=str(db_path)))

        # optional tables
        optional_tables = ['recipes','recipe_ingredients','loot_pools','loot_pool_items']
        for t in optional_tables:
            if t not in tables:
                issues.append(Issue('warning','DB.OPTIONAL_TABLE_MISSING',f"Таблица {t} отсутствует (это ок для минимальной сборки).", file=str(db_path)))

        # fk-like checks if tables exist
        cur = con.cursor()
        if 'recipe_ingredients' in tables:
            # detect likely column names
            ricols = set(table_columns(con,'recipe_ingredients'))
            if 'item_id' in ricols:
                cur.execute("SELECT COUNT(*) FROM recipe_ingredients ri LEFT JOIN items i ON i.item_id=ri.item_id WHERE i.item_id IS NULL")
                n = cur.fetchone()[0]
                if n:
                    # В реальных пайплайнах БД может не иметь жёстких FK-констрейнтов.
                    # Поэтому «битые ссылки» считаем WARNING по умолчанию (в strict/warnings-as-errors станет ERROR).
                    issues.append(Issue('warning','DB.BROKEN_REF',f"recipe_ingredients: {n} строк ссылаются на несуществующий items.item_id", file=str(db_path)))
        if 'loot_pool_items' in tables:
            lpcols = set(table_columns(con,'loot_pool_items'))
            if 'item_id' in lpcols:
                cur.execute("SELECT COUNT(*) FROM loot_pool_items lpi LEFT JOIN items i ON i.item_id=lpi.item_id WHERE i.item_id IS NULL")
                n = cur.fetchone()[0]
                if n:
                    issues.append(Issue('warning','DB.BROKEN_REF',f"loot_pool_items: {n} строк ссылаются на несуществующий items.item_id", file=str(db_path)))

        # strict expectations for content bundle
        if strict:
            expected = {'city_shops','city_shop_inventory','loot_pools','loot_pool_items'}
            miss = sorted(expected - tables)
            if miss:
                issues.append(Issue('error','DB.MISSING_EXPECTED_TABLE',f"В strict режиме ожидаю таблицы: {', '.join(miss)}", file=str(db_path)))

    con.close()
    return issues


def validate_bestiary_db(db_path: Path, *, strict: bool = False) -> List[Issue]:
    issues: List[Issue] = []
    try:
        con = open_ro(db_path)
    except Exception as e:
        return [Issue('error','DB.OPEN_FAILED',f'Не удалось открыть SQLite: {e}', file=str(db_path))]

    with con:
        tables = set(list_tables(con))
        required_min = {'monsters','meta'}
        missing = sorted(required_min - tables)
        if missing:
            issues.append(Issue('error','DB.MISSING_TABLE',f"Отсутствуют обязательные таблицы: {', '.join(missing)}", file=str(db_path)))
            return issues
        if strict and 'attacks' not in tables:
            issues.append(Issue('error','DB.MISSING_EXPECTED_TABLE','В strict режиме ожидаю таблицу attacks', file=str(db_path)))

    con.close()
    return issues
