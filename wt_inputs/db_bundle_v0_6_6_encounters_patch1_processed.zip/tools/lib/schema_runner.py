"""JSON Schema runner with optional dependency on jsonschema.

If `jsonschema` is installed, we use Draft 2020-12 validation.
Otherwise we only run lightweight structural checks + invariants.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional


@dataclass
class Issue:
    severity: str  # "error"|"warning"
    code: str
    message: str
    path: Optional[str] = None
    file: Optional[str] = None
    hint: Optional[str] = None


def _format_jsonschema_path(p) -> str:
    if not p:
        return ""
    out = "$"
    for tok in list(p):
        if isinstance(tok, int):
            out += f"[{tok}]"
        else:
            out += f".{tok}"
    return out


def validate_jsonschema(instance: Any, schema: Dict[str, Any], file_label: str, *, strict: bool = True) -> List[Issue]:
    issues: List[Issue] = []
    try:
        import jsonschema
        from jsonschema import Draft202012Validator
    except Exception:
        if strict:
            issues.append(Issue(
                severity="warning",
                code="SCHEMA.NO_JSONSCHEMA",
                message="Библиотека 'jsonschema' не установлена — выполняю только инварианты. Для полной проверки: pip install jsonschema",
                file=file_label,
            ))
        return issues

    try:
        Draft202012Validator.check_schema(schema)
    except Exception as e:
        issues.append(Issue(
            severity="error",
            code="SCHEMA.INVALID_SCHEMA",
            message=f"Некорректная JSON Schema: {e}",
            file=file_label,
        ))
        return issues

    v = Draft202012Validator(schema)
    for err in sorted(v.iter_errors(instance), key=lambda e: list(e.absolute_path)):
        issues.append(Issue(
            severity="error",
            code="SCHEMA.VIOLATION",
            message=err.message,
            path=_format_jsonschema_path(err.absolute_path),
            file=file_label,
        ))
    return issues
