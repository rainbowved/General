#!/usr/bin/env python3
"""Stage5 validator CLI.

Usage examples:
  python tools/validate.py core --core-dir content/core
  python tools/validate.py save --save-dir save/ --core-dir content/core
  python tools/validate.py changelog --file turn_001.json --core-dir content/core
  python tools/validate.py content-db --db rpg_items.sqlite
  python tools/validate.py all --core-dir content/core --save-dir save/ --db rpg_items.sqlite
"""

from __future__ import annotations

import sys
from pathlib import Path as _Path
# ensure project root is importable when running as a script
sys.path.insert(0, str(_Path(__file__).resolve().parents[1]))

import argparse
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional

from tools.lib.loader import LoadError, load_json, read_save_bundle
from tools.lib.schema_runner import Issue, validate_jsonschema
from tools.lib.invariants import core_invariants, save_invariants, changelog_invariants
from tools.lib.sqlite_inspect import validate_items_db, validate_bestiary_db

TOOL_VERSION = "stage5.v0.1"


def now_z() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%SZ')


def load_schema(schemas_dir: Path, name: str) -> Dict[str, Any]:
    return load_json(schemas_dir / name)


def write_report(path: Path, report: Dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    import json
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')


def issues_to_report(target: str, issues: List[Issue], inputs: Dict[str, Any]) -> Dict[str, Any]:
    out = {
        'ok': not any(i.severity == 'error' for i in issues),
        'target': target,
        'run_at': now_z(),
        'tool_version': TOOL_VERSION,
        'inputs': inputs,
        'stats': {
            'errors': sum(1 for i in issues if i.severity == 'error'),
            'warnings': sum(1 for i in issues if i.severity == 'warning'),
        },
        'issues': [i.__dict__ for i in issues],
    }
    return out


def print_human(report: Dict[str, Any], *, quiet: bool = False) -> None:
    if quiet:
        return

    ok = report['ok']
    head = 'OK' if ok else 'FAILED'
    print(f"[{head}] target={report['target']} errors={report['stats']['errors']} warnings={report['stats']['warnings']}")

    for it in report['issues']:
        sev = it['severity'].upper()
        loc = []
        if it.get('file'):
            loc.append(str(it['file']))
        if it.get('path'):
            loc.append(str(it['path']))
        loc_s = (' @ ' + ' :: '.join(loc)) if loc else ''
        print(f"- {sev} {it['code']}{loc_s}: {it['message']}")
        if it.get('hint'):
            print(f"    hint: {it['hint']}")


def validate_core(args) -> Dict[str, Any]:
    core_dir = Path(args.core_dir)
    schemas_dir = Path(args.schemas_dir)

    issues: List[Issue] = []

    manifest_path = core_dir / 'core_manifest.json'
    try:
        manifest = load_json(manifest_path)
    except LoadError as e:
        issues.append(Issue('error','CORE.MANIFEST_LOAD',str(e), file=str(manifest_path)))
        return issues_to_report('core', issues, {'core_dir': str(core_dir)})

    # schema validation
    issues += validate_jsonschema(manifest, load_schema(schemas_dir, 'core_manifest.schema.json'), 'core_manifest.json')

    # load optional core files
    def _try(name):
        p = core_dir / f"{name}.json"
        return load_json(p) if p.exists() else None

    enums = _try('enums')
    caps = _try('caps')
    formulas = _try('formulas')
    aliases = _try('aliases')
    rng = _try('rng')

    if enums:
        issues += validate_jsonschema(enums, load_schema(schemas_dir, 'core_enums.schema.json'), 'enums.json')
    if caps:
        issues += validate_jsonschema(caps, load_schema(schemas_dir, 'core_caps.schema.json'), 'caps.json')
    if formulas:
        issues += validate_jsonschema(formulas, load_schema(schemas_dir, 'core_formulas.schema.json'), 'formulas.json')
    if rng:
        issues += validate_jsonschema(rng, load_schema(schemas_dir, 'core_rng.schema.json'), 'rng.json')

    issues += core_invariants(core_dir, manifest, enums=enums, aliases=aliases, caps=caps, formulas=formulas, rng=rng)

    return issues_to_report('core', issues, {'core_dir': str(core_dir)})


def validate_save(args) -> Dict[str, Any]:
    save_dir = Path(args.save_dir)
    schemas_dir = Path(args.schemas_dir)

    issues: List[Issue] = []

    # core optional
    core_caps = None
    core_rng = None
    if args.core_dir:
        core_dir = Path(args.core_dir)
        try:
            caps_path = core_dir / 'caps.json'
            rng_path = core_dir / 'rng.json'
            if caps_path.exists():
                core_caps = load_json(caps_path)
            if rng_path.exists():
                core_rng = load_json(rng_path)
        except LoadError as e:
            issues.append(Issue('warning','SAVE.CORE_LOAD',str(e)))

    try:
        bundle = read_save_bundle(save_dir)
    except LoadError as e:
        issues.append(Issue('error','SAVE.BUNDLE_LOAD',str(e), file=str(save_dir)))
        return issues_to_report('save', issues, {'save_dir': str(save_dir)})

    # schema validations
    issues += validate_jsonschema(bundle['player'], load_schema(schemas_dir, 'save_player.schema.json'), 'player.json')
    issues += validate_jsonschema(bundle['world'], load_schema(schemas_dir, 'save_world.schema.json'), 'world.json')
    issues += validate_jsonschema(bundle['inventory'], load_schema(schemas_dir, 'save_inventory.schema.json'), 'inventory.json')
    issues += validate_jsonschema(bundle['progress'], load_schema(schemas_dir, 'save_progress.schema.json'), 'progress.json')
    if bundle.get('session') is not None:
        issues += validate_jsonschema(bundle['session'], load_schema(schemas_dir, 'session.schema.json'), 'session.json')

    issues += save_invariants(bundle, core_caps=core_caps, core_rng=core_rng)

    return issues_to_report('save', issues, {'save_dir': str(save_dir), 'core_dir': str(args.core_dir) if args.core_dir else None})


def validate_changelog(args) -> Dict[str, Any]:
    file_path = Path(args.file)
    schemas_dir = Path(args.schemas_dir)

    issues: List[Issue] = []

    core_rng = None
    if args.core_dir:
        rng_path = Path(args.core_dir) / 'rng.json'
        if rng_path.exists():
            try:
                core_rng = load_json(rng_path)
            except LoadError as e:
                issues.append(Issue('warning','CL.CORE_RNG_LOAD',str(e)))

    try:
        ch = load_json(file_path)
    except LoadError as e:
        issues.append(Issue('error','CL.LOAD',str(e), file=str(file_path)))
        return issues_to_report('changelog', issues, {'file': str(file_path)})

    issues += validate_jsonschema(ch, load_schema(schemas_dir, 'changelog.schema.json'), file_path.name)
    issues += changelog_invariants(ch, core_rng=core_rng)

    return issues_to_report('changelog', issues, {'file': str(file_path), 'core_dir': str(args.core_dir) if args.core_dir else None})


def validate_world(args) -> Dict[str, Any]:
    """Validate navigation world graphs (Stage8)."""
    issues: List[Issue] = []
    inputs = {'world_dir': args.world_dir, 'core_dir': getattr(args, 'core_dir', None)}

    schemas_dir = Path(args.schemas_dir)
    world_dir = Path(args.world_dir)
    project_root = Path(__file__).resolve().parents[1]

    # Schemas
    try:
        schema_graph = load_schema(schemas_dir, 'world_graph.schema.json')
        schema_manifest = load_schema(schemas_dir, 'world_manifest.schema.json')
    except Exception as e:
        issues.append(Issue(severity='error', code='world.schema_load_failed', message=str(e), path='', file='schemas'))
        return issues_to_report('world', issues, inputs)

    # Load manifest (optional, but strongly recommended)
    manifest_path = world_dir / 'world_manifest.json'
    graphs: List[Dict[str, Any]] = []
    portals: List[Dict[str, Any]] = []
    if manifest_path.exists():
        try:
            manifest = load_json(manifest_path)
            issues += validate_jsonschema(manifest, schema_manifest, 'world_manifest.json')
            graphs = manifest.get('graphs', [])
            portals = manifest.get('portals', [])
        except Exception as e:
            issues.append(Issue(severity='error', code='world.manifest_load_failed', message=str(e), path='', file=str(manifest_path)))
            return issues_to_report('world', issues, inputs)
    else:
        # fallback: discover *graph*.json inside world_dir
        issues.append(Issue(severity='warning', code='world.manifest_missing', message='world_manifest.json не найден; графы будут найдены по маске *graph*.json', path='', file=str(world_dir)))
        graphs = []
        for p in sorted(world_dir.glob('*graph*.json')):
            graphs.append({'graph_id': p.stem.upper(), 'file': str(p)})

    # Load graph files
    graph_by_id: Dict[str, Dict[str, Any]] = {}
    file_by_id: Dict[str, str] = {}

    for g in graphs:
        gid = g.get('graph_id')
        rel = g.get('file')
        if not gid or not rel:
            issues.append(Issue(severity='error', code='world.manifest_bad_graph_entry', message='graph entry должен содержать graph_id и file', path='graphs[]', file=str(manifest_path)))
            continue

        # Resolve path: if rel is absolute -> use it; else relative to project_root
        gp = Path(rel)
        if not gp.is_absolute():
            gp = project_root / rel
            if not gp.exists():
                gp = world_dir / Path(rel).name  # allow "cityhub_graph.json" in manifest
        if not gp.exists():
            issues.append(Issue(severity='error', code='world.graph_missing', message=f'Файл графа не найден: {rel}', path='graphs.file', file=str(manifest_path)))
            continue

        try:
            data = load_json(gp)
        except Exception as e:
            issues.append(Issue(severity='error', code='world.graph_load_failed', message=str(e), path='', file=str(gp)))
            continue

        issues += validate_jsonschema(data, schema_graph, gp.name)

        graph_by_id[str(gid)] = data
        file_by_id[str(gid)] = str(gp)

    # Per-graph invariants
    from collections import defaultdict, deque
    import re as _re

    for gid, graph in graph_by_id.items():
        gfile = file_by_id.get(gid, gid)
        nodes = graph.get('nodes', [])
        edges = graph.get('edges', [])

        node_ids: List[str] = [n.get('node_id') for n in nodes if isinstance(n, dict)]
        # unique node ids
        seen = set()
        for i, nid in enumerate(node_ids):
            if not nid:
                issues.append(Issue(severity='error', code='world.node_id_missing', message='node_id обязателен', path=f'nodes[{i}].node_id', file=gfile))
                continue
            if nid in seen:
                issues.append(Issue(severity='error', code='world.node_id_duplicate', message=f'duplicate node_id={nid}', path=f'nodes[{i}].node_id', file=gfile))
            seen.add(nid)

        start = graph.get('start_node_id')
        if start and start not in seen:
            issues.append(Issue(severity='error', code='world.start_missing', message=f'start_node_id={start} не найден среди nodes', path='start_node_id', file=gfile))

        # edges reference existing nodes
        edge_ids = set()
        adj = defaultdict(set)      # undirected adjacency for reachability
        adj_dir = defaultdict(set)  # directed (from -> to) if bidirectional=false
        for i, e in enumerate(edges):
            if not isinstance(e, dict):
                issues.append(Issue(severity='error', code='world.edge_not_object', message='edge должен быть объектом', path=f'edges[{i}]', file=gfile))
                continue
            a = e.get('from'); b = e.get('to'); eid = e.get('edge_id')
            if not eid:
                issues.append(Issue(severity='error', code='world.edge_id_missing', message='edge_id обязателен', path=f'edges[{i}].edge_id', file=gfile))
            else:
                if eid in edge_ids:
                    issues.append(Issue(severity='error', code='world.edge_id_duplicate', message=f'duplicate edge_id={eid}', path=f'edges[{i}].edge_id', file=gfile))
                edge_ids.add(eid)
            if a not in seen:
                issues.append(Issue(severity='error', code='world.edge_from_unknown', message=f'from={a} не существует', path=f'edges[{i}].from', file=gfile))
            if b not in seen:
                issues.append(Issue(severity='error', code='world.edge_to_unknown', message=f'to={b} не существует', path=f'edges[{i}].to', file=gfile))
            if a in seen and b in seen:
                if e.get('bidirectional', True):
                    adj[a].add(b); adj[b].add(a)
                else:
                    adj_dir[a].add(b)

        # connectivity (allowed nodes only)
        allowed = {n.get('node_id'): (n.get('allowed', True) is not False) for n in nodes if isinstance(n, dict) and n.get('node_id')}
        if start in seen:
            q = deque([start])
            vis = set([start])
            while q:
                cur = q.popleft()
                for nxt in adj.get(cur, set()):
                    if nxt not in vis:
                        vis.add(nxt); q.append(nxt)
                for nxt in adj_dir.get(cur, set()):
                    if nxt not in vis:
                        vis.add(nxt); q.append(nxt)
            for nid in seen:
                if allowed.get(nid, True) and nid not in vis:
                    issues.append(Issue(severity='error', code='world.unreachable_node', message=f'узел недостижим от start_node_id: {nid}', path='nodes[].node_id', file=gfile))

        # region-specific checks
        if gid.upper() == 'OVERWALL':
            tier_by = {n.get('node_id'): n.get('tier') for n in nodes if isinstance(n, dict)}
            tags_by = {n.get('node_id'): set(n.get('tags', [])) for n in nodes if isinstance(n, dict)}
            for i, e in enumerate(edges):
                a = e.get('from'); b = e.get('to')
                if a not in tier_by or b not in tier_by:
                    continue
                ta, tb = tier_by[a], tier_by[b]
                if 'TRANSITION' in tags_by.get(a, set()) or 'TRANSITION' in tags_by.get(b, set()):
                    continue
                try:
                    if abs(int(ta) - int(tb)) > 1:
                        issues.append(Issue(severity='error', code='world.overwall_tier_jump', message=f'резкий прыжок tier по ребру: {a}(t{ta}) <-> {b}(t{tb})', path=f'edges[{i}]', file=gfile))
                except Exception:
                    pass

        if gid.upper() == 'TOWER':
            floor_nodes = set()
            for nid in seen:
                m = _re.match(r'^TOWER_F(\d{3})$', nid)
                if m:
                    floor_nodes.add(int(m.group(1)))
            missing = [f for f in range(1, 101) if f not in floor_nodes]
            if missing:
                issues.append(Issue(severity='error', code='world.tower_missing_floors', message=f'Отсутствуют этажи: {missing[:10]}{"..." if len(missing)>10 else ""}', path='nodes', file=gfile))

            und_adj = defaultdict(set)
            for e in edges:
                a=e.get('from'); b=e.get('to')
                if a and b:
                    und_adj[a].add(b); und_adj[b].add(a)

            def floor_id(f:int)->str:
                return f"TOWER_F{f:03d}"

            for f in range(1, 100):
                a=floor_id(f); b=floor_id(f+1)
                if a in seen and b in seen and b not in und_adj.get(a,set()):
                    issues.append(Issue(severity='error', code='world.tower_missing_edge', message=f'Нет ребра между {a} и {b}', path='edges', file=gfile))

            tags_by = {n.get('node_id'): set(n.get('tags', [])) for n in nodes if isinstance(n, dict)}
            for f in range(10, 101, 10):
                nid=floor_id(f)
                if nid in seen and 'BOSS_FLOOR' not in tags_by.get(nid,set()):
                    issues.append(Issue(severity='error', code='world.tower_boss_tag_missing', message=f'Этаж {nid} должен иметь тег BOSS_FLOOR', path='nodes[].tags', file=gfile))

            for f in range(10, 101, 10):
                boss=floor_id(f)
                safe=f"TOWER_SAFE_{f:03d}"
                if boss in seen:
                    if safe not in seen:
                        issues.append(Issue(severity='error', code='world.tower_safe_missing', message=f'Нет безопасной комнаты {safe} для boss floor {boss}', path='nodes', file=gfile))
                    else:
                        if safe not in und_adj.get(boss,set()):
                            issues.append(Issue(severity='error', code='world.tower_safe_unlinked', message=f'{safe} не связан ребром с {boss}', path='edges', file=gfile))

    # Portals invariants (if manifest present)
    if manifest_path.exists():
        portal_ids = set()
        for i, p in enumerate(portals):
            pid = p.get('portal_id')
            if not pid:
                issues.append(Issue(severity='error', code='world.portal_id_missing', message='portal_id обязателен', path=f'portals[{i}].portal_id', file=str(manifest_path)))
            else:
                if pid in portal_ids:
                    issues.append(Issue(severity='error', code='world.portal_id_duplicate', message=f'duplicate portal_id={pid}', path=f'portals[{i}].portal_id', file=str(manifest_path)))
                portal_ids.add(pid)

            frm = p.get('from', {}) or {}
            to = p.get('to', {}) or {}
            for side, ep in [('from', frm), ('to', to)]:
                gid = ep.get('graph_id'); nid = ep.get('node_id')
                if gid not in graph_by_id:
                    issues.append(Issue(severity='error', code='world.portal_graph_unknown', message=f'{side}.graph_id={gid} не найден', path=f'portals[{i}].{side}.graph_id', file=str(manifest_path)))
                    continue
                graph = graph_by_id[gid]
                node_set = set(n.get('node_id') for n in graph.get('nodes', []) if isinstance(n, dict))
                if nid not in node_set:
                    issues.append(Issue(severity='error', code='world.portal_node_unknown', message=f'{side}.node_id={nid} не найден в графе {gid}', path=f'portals[{i}].{side}.node_id', file=str(manifest_path)))

    return issues_to_report('world', issues, inputs)




def validate_encounters(args) -> Dict[str, Any]:
    enc_dir = Path(args.enc_dir)
    world_dir = Path(args.world_dir) if getattr(args, 'world_dir', None) else None

    issues: List[Issue] = []
    inputs = {'enc_dir': str(enc_dir), 'world_dir': str(world_dir) if world_dir else None, 'core_dir': getattr(args, 'core_dir', None)}

    if not enc_dir.exists():
        issues.append(Issue('error','ENCOUNTERS.NOT_FOUND',f'Папка encounters не найдена: {enc_dir}', file=str(enc_dir)))
        return issues_to_report('encounters', issues, inputs)

    tables_path = enc_dir / 'encounter_tables.json'
    bands_path = enc_dir / 'spawn_bands.json'

    if not tables_path.exists():
        issues.append(Issue('error','ENCOUNTERS.MISSING_FILE',f'Файл не найден: {tables_path}', file=str(tables_path)))
        return issues_to_report('encounters', issues, inputs)
    if not bands_path.exists():
        issues.append(Issue('error','ENCOUNTERS.MISSING_FILE',f'Файл не найден: {bands_path}', file=str(bands_path)))
        return issues_to_report('encounters', issues, inputs)

    try:
        tables = load_json(tables_path)
    except Exception as e:
        issues.append(Issue('error','ENCOUNTERS.JSON_INVALID',f'Не удалось прочитать JSON: {e}', file=str(tables_path)))
        return issues_to_report('encounters', issues, inputs)

    try:
        bands = load_json(bands_path)
    except Exception as e:
        issues.append(Issue('error','ENCOUNTERS.JSON_INVALID',f'Не удалось прочитать JSON: {e}', file=str(bands_path)))
        return issues_to_report('encounters', issues, inputs)    # Schema validate
    schemas_dir = Path(args.schemas_dir)
    schema_tables = load_schema(schemas_dir, 'encounter_tables.schema.json')
    schema_bands = load_schema(schemas_dir, 'spawn_bands.schema.json')
    issues += validate_jsonschema(tables, schema_tables, str(tables_path))
    issues += validate_jsonschema(bands, schema_bands, str(bands_path))


    # Invariants
    table_list = tables.get('tables', []) if isinstance(tables, dict) else []
    band_list = bands.get('bands', []) if isinstance(bands, dict) else []

    table_ids = []
    for i, t in enumerate(table_list):
        tid = (t or {}).get('table_id')
        if not tid:
            issues.append(Issue('error','ENCOUNTERS.TABLE_ID_MISSING',f'table_id обязателен (tables[{i}])', path=f'tables[{i}].table_id', file=str(tables_path)))
            continue
        table_ids.append(tid)
    if len(set(table_ids)) != len(table_ids):
        seen=set(); dups=set()
        for tid in table_ids:
            if tid in seen: dups.add(tid)
            seen.add(tid)
        issues.append(Issue('error','ENCOUNTERS.TABLE_ID_DUP',f'duplicate table_id: {sorted(dups)}', path='tables[].table_id', file=str(tables_path)))

    band_ids = []
    for i, b in enumerate(band_list):
        bid = (b or {}).get('spawn_band_id')
        if not bid:
            issues.append(Issue('error','ENCOUNTERS.BAND_ID_MISSING',f'spawn_band_id обязателен (bands[{i}])', path=f'bands[{i}].spawn_band_id', file=str(bands_path)))
            continue
        band_ids.append(bid)
    if len(set(band_ids)) != len(band_ids):
        seen=set(); dups=set()
        for bid in band_ids:
            if bid in seen: dups.add(bid)
            seen.add(bid)
        issues.append(Issue('error','ENCOUNTERS.BAND_ID_DUP',f'duplicate spawn_band_id: {sorted(dups)}', path='bands[].spawn_band_id', file=str(bands_path)))

    band_set = set(band_ids)

    # Validate member count ranges + monster existence (warning)
    monster_set = None
    bestiary_path = Path('json') / 'bestiary_monsters.json'
    if bestiary_path.exists():
        try:
            bestiary = load_json(bestiary_path)
            monster_set = {m.get('monster_id') for m in bestiary.get('monsters', []) if isinstance(m, dict) and m.get('monster_id')}
        except Exception:
            monster_set = None

    for bi, b in enumerate(band_list):
        bid = (b or {}).get('spawn_band_id', '?')
        for mi, mem in enumerate((b or {}).get('members', []) or []):
            cmin = mem.get('count_min')
            cmax = mem.get('count_max')
            if isinstance(cmin, int) and isinstance(cmax, int) and cmax < cmin:
                issues.append(Issue('error','ENCOUNTERS.COUNT_RANGE',f'{bid} members[{mi}] count_max < count_min', path=f'bands[{bi}].members[{mi}]', file=str(bands_path)))
            mid = mem.get('monster_id')
            if monster_set is not None and mid and mid not in monster_set:
                issues.append(Issue('warning','ENCOUNTERS.MONSTER_UNKNOWN',f'{bid} members[{mi}] monster_id не найден в bestiary_monsters.json: {mid}', path=f'bands[{bi}].members[{mi}].monster_id', file=str(bands_path)))

    # EncounterTable entries reference spawn bands
    for ti, t in enumerate(table_list):
        tid = (t or {}).get('table_id', '?')
        entries = (t or {}).get('entries', []) or []
        for ei, e in enumerate(entries):
            w = e.get('weight')
            if not isinstance(w, int) or w <= 0:
                issues.append(Issue('error','ENCOUNTERS.ENTRY_WEIGHT',f'{tid} entries[{ei}] weight должен быть int > 0', path=f'tables[{ti}].entries[{ei}].weight', file=str(tables_path)))
            sb = e.get('spawn_band_id')
            if sb and sb not in band_set:
                issues.append(Issue('error','ENCOUNTERS.SPAWN_BAND_MISSING',f'{tid} entries[{ei}] spawn_band_id не найден: {sb}', path=f'tables[{ti}].entries[{ei}].spawn_band_id', file=str(tables_path)))

    # Cross-check with world graphs: every referenced encounter_table_id must exist
    if world_dir and world_dir.exists():
        needed=set()
        for gname in ['cityhub_graph.json','overwall_graph.json','tower_graph.json']:
            gp=world_dir/gname
            if not gp.exists():
                continue
            g=load_json(gp)
            for n in g.get('nodes', []):
                tid=(n.get('links') or {}).get('encounter_table_id')
                if tid:
                    needed.add(tid)
        table_set=set(table_ids)
        missing=sorted(list(needed - table_set))
        if missing:
            issues.append(Issue('error','ENCOUNTERS.WORLD_REF_MISSING',f'World graphs ссылаются на отсутствующие table_id: {missing}', path='world.nodes[].links.encounter_table_id', file=str(world_dir)))

        # Tower boss floors sanity: boss nodes should resolve to boss-ish tables
        tower_path = world_dir / 'tower_graph.json'
        if tower_path.exists():
            tg=load_json(tower_path)
            nodes=tg.get('nodes', [])
            for n in nodes:
                if 'BOSS_FLOOR' in (n.get('tags') or []):
                    tid=(n.get('links') or {}).get('encounter_table_id')
                    if tid and 'BOSS' not in tid:
                        issues.append(Issue('warning','ENCOUNTERS.BOSS_TABLE_HINT',f"Boss node {n.get('node_id')} ссылается на non-boss table_id={tid}", path='nodes[].links.encounter_table_id', file=str(tower_path)))

    return issues_to_report('encounters', issues, inputs)

def validate_content_db(args) -> Dict[str, Any]:
    db_path = Path(args.db)

    issues: List[Issue] = []

    if not db_path.exists():
        issues.append(Issue('error','DB.NOT_FOUND',f'Файл БД не найден: {db_path}', file=str(db_path)))
        return issues_to_report('content-db', issues, {'db': str(db_path)})

    # Decide type by tables
    # Try items db first
    issues_items = validate_items_db(db_path, strict=args.strict)
    if not any(i.severity == 'error' and i.code.startswith('DB.MISSING_TABLE') for i in issues_items):
        issues += issues_items
    else:
        # maybe bestiary
        issues += validate_bestiary_db(db_path, strict=args.strict)

    return issues_to_report('content-db', issues, {'db': str(db_path), 'strict': args.strict})


def validate_all(args) -> Dict[str, Any]:
    issues: List[Issue] = []
    inputs = {'core_dir': args.core_dir, 'save_dir': args.save_dir, 'db': args.db}

    if args.core_dir:
        r = validate_core(argparse.Namespace(core_dir=args.core_dir, schemas_dir=args.schemas_dir))
        issues += [Issue(**i) for i in r['issues']]

    if args.save_dir:
        r = validate_save(argparse.Namespace(save_dir=args.save_dir, core_dir=args.core_dir, schemas_dir=args.schemas_dir))
        issues += [Issue(**i) for i in r['issues']]

    if args.file:
        r = validate_changelog(argparse.Namespace(file=args.file, core_dir=args.core_dir, schemas_dir=args.schemas_dir))
        issues += [Issue(**i) for i in r['issues']]

    if args.db:
        r = validate_content_db(argparse.Namespace(db=args.db, strict=args.strict))
        issues += [Issue(**i) for i in r['issues']]

    if args.enc_dir:
        r = validate_encounters(argparse.Namespace(enc_dir=args.enc_dir, world_dir=args.world_dir, core_dir=args.core_dir, schemas_dir=args.schemas_dir))
        issues += [Issue(**i) for i in r['issues']]

    # deduplicate identical issues a bit
    uniq = []
    seen = set()
    for i in issues:
        key = (i.severity, i.code, i.message, i.path, i.file)
        if key in seen:
            continue
        seen.add(key)
        uniq.append(i)

    return issues_to_report('all', uniq, inputs)


def main(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog='validate', description='Validate core/save/changelog/world/content db')
    ap.add_argument('--schemas-dir', default=str(Path(__file__).resolve().parents[1] / 'schemas'), help='Папка schemas/*.schema.json')
    ap.add_argument('--report', default=None, help='Записать JSON отчёт в файл')
    ap.add_argument('--quiet', action='store_true', help='Не печатать текстовый вывод')

    sub = ap.add_subparsers(dest='cmd', required=True)

    p_core = sub.add_parser('core')
    p_core.add_argument('--core-dir', required=True)

    p_save = sub.add_parser('save')
    p_save.add_argument('--save-dir', required=True)
    p_save.add_argument('--core-dir', default=None)

    p_ch = sub.add_parser('changelog')
    p_ch.add_argument('--file', required=True)
    p_ch.add_argument('--core-dir', default=None)


    p_world = sub.add_parser('world')
    p_world.add_argument('--world-dir', required=True)
    p_world.add_argument('--core-dir', default=None)

    p_enc = sub.add_parser('encounters')
    p_enc.add_argument('--enc-dir', required=True)
    p_enc.add_argument('--world-dir', default=None)
    p_enc.add_argument('--core-dir', default=None)



    p_db = sub.add_parser('content-db')
    p_db.add_argument('--db', required=True)
    p_db.add_argument('--strict', action='store_true')

    p_all = sub.add_parser('all')
    p_all.add_argument('--core-dir', default=None)
    p_all.add_argument('--save-dir', default=None)
    p_all.add_argument('--world-dir', default=None)
    p_all.add_argument('--enc-dir', default=None)
    p_all.add_argument('--db', default=None)
    p_all.add_argument('--file', default=None, help='Опционально: changelog файл')
    p_all.add_argument('--strict', action='store_true')

    args = ap.parse_args(argv)

    if args.cmd == 'core':
        report = validate_core(args)
    elif args.cmd == 'save':
        report = validate_save(args)
    elif args.cmd == 'changelog':
        report = validate_changelog(args)
    elif args.cmd == 'world':
        report = validate_world(args)
    elif args.cmd == 'encounters':
        report = validate_encounters(args)
    elif args.cmd == 'content-db':
        report = validate_content_db(args)
    elif args.cmd == 'all':
        report = validate_all(args)
    else:
        raise SystemExit(2)

    if args.report:
        write_report(Path(args.report), report)

    print_human(report, quiet=args.quiet)

    return 0 if report['ok'] else 1


if __name__ == '__main__':
    raise SystemExit(main())