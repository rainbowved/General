# REPORT_STAGE9_ENCOUNTERS
Generated: 0.6.6-patch1 at 76e3b5b5…
## Summary
- EncounterTables: 37 (referenced by world graphs)
- SpawnBands: 85 (from existing templates)
- Tables without entries (stubs): 0
- Boss tables: 13; with POOL_LEG_BOSS_* mapped: 13

## Decisions / Assumptions
- Не меняем world_graph: encounter_table_id в узлах трактуется как table_id EncounterTable.
- SpawnBand построен 1:1 из существующих encounter_templates (template_id → spawn_band_id).
- Веса entries выставлены равными (100) — без усложнений, т.к. в templates нет явных весов.
- loot_pool_id: по умолчанию UNDEAD→POOL_ALCH_UNDEAD, BEAST→POOL_COOK_BEAST_MEAT; для BOSS пытаемся подставить POOL_LEG_BOSS_<boss_monster_id>.
