# HANDOFF: WT Client Stage 10 → C32

Дата подготовки: 2026-02-19

## Что нужно получить на выходе
Собрать финальный архив клиента: **WT_client_stage_C32.zip** (Stage 10/10).

Критерии готовности Stage 10:
- UI: New/Load/Save; экраны Character + Inventory; запуск действий через dispatcher; просмотр event log.
- TURNPACK loop: Build TURNPACK → Copy; Paste master CHANGELOG JSON → Apply → autosave.
- Golden demo: “New game → 1 encounter → loot → craft → save → load” работает из коробки.
- README: пошагово “как играть/как общаться с мастером”.

## Входные артефакты (прикладываю в этом бандле)
- WT_client_stage_C31.zip
- db_bundle_v0_6_6_encounters_patch1_processed.zip
- concept_v0_6_3_cityhub_backbone.odt

SHA-256:
```json
{
  "WT_client_stage_C31.zip": "8613a6c0c1f90a8421764fef08bff9313ea47465406865059ebce1881e415a5a",
  "db_bundle_v0_6_6_encounters_patch1_processed.zip": "8309984607dc227d7c9a2c6bc8b3dd6678d6f9900782390d9a30a9943e9ce78d",
  "concept_v0_6_3_cityhub_backbone.odt": "1a28cff58208a98adc99bb48d6572e9d8f4777c5c891a7275e80a1edf608ff38"
}
```

## Обязательная найденная проблема (починить)
### ContentPackLoader: неверный выбор root у directory pack
Симптом: если внутри подпапки `db_bundle/` есть `rpg_items.sqlite`, loader может выбрать `db_bundle/` как root и потом “не видеть” `specs/` и `demo/`.

**Фикс в `_choose_dir_root_path(base)`**:
1) Сначала проверь базовый root:
   - если в `base` есть `specs/` и (есть `db_bundle/` или `demo/`) → сразу выбирай `base`
2) И только иначе перебирай подпапки.

Псевдокод:
```py
if (base/"specs").is_dir() and ((base/"db_bundle").is_dir() or (base/"demo").is_dir()):
    return base
# else: scan subdirs, score them
```

## Стратегия “из коробки”: bundled demo pack
Добавить в репозиторий клиента:
- `bundles/WT_demo_pack_C32.zip`

Внутри:
- `db_bundle/` = содержимое db_bundle_v0_6_6_encounters_patch1_processed.zip
- `specs/` минимум:
  - rng_streams.json (можно копировать из content/core/rng.json в репо клиента)
  - node_interactions.json (минимальный fallback)
  - turnpack_schema.json (permissive; соответствует TurnpackBuilder)
- `demo/` = минимальный валидный save + session + пустой changelog
- `concept/` = ODT

Обновить дефолтный конфиг:
- `wt_client/config.json: datapack_path = "./bundles/WT_demo_pack_C32.zip"`

## UI чеклист по шагам
### Шаг 0 — распаковать и запустить
- распаковать C31
- `pytest -q` (зафиксировать статус)
- `python -m wt_client --ui` (или команда проекта)

### Шаг 1 — Save flow
- New game (создать слот из demo template)
- Load game (выбрать слот)
- Save/Load roundtrip

### Шаг 2 — Экран персонажа и инвентарь
- Character tab: HP/Shield/статусы/локация/вес/метры (best-effort)
- Inventory tab: список item_id/qty; кнопка Use → dispatcher action `use_item`

### Шаг 3 — Action run через dispatcher
Кнопки/формы минимум:
- PROCEED (или MOVE/REST если в проекте так)
- CRAFT (recipe_id + times)
- ASK_MASTER (текст)

После действия:
- показать events
- apply через ChangelogEngine
- сохранить сейв

### Шаг 4 — TURNPACK/CHANGELOG loop
- Build TURNPACK → JSON + Copy
- Paste master changelog JSON → Apply → новый сейв
- event log (последние N) + Copy

### Шаг 5 — Golden demo кнопка
Кнопка “Golden demo” делает сценарий:
- New game
- 1 encounter/бой (если не выпал — повторить N раз; можно использовать гарантированный демо-узел/пул)
- Loot events → apply
- Craft: первый доступный recipe_id; если нет ингров — demo-only grant через событие `INVENTORY_ADD_INSTANCES` (только внутри golden demo)
- Save → Load → показать OK

### Шаг 6 — README
- Быстрый старт
- Как общаться с мастером: ASK_MASTER → turnpack → вставить CHANGELOG → Apply
- Golden demo
- Ограничения

### Шаг 7 — сборка C32
- очистить `__pycache__`, `.pytest_cache`
- `pytest -q` зелёный
- упаковать `WT_client_stage_C32.zip`

## Важно: ограничения
- Никаких новых игровых механик. Только UI/протокол/инфраструктура.
- Все изменения состояния — только через ChangelogEngine (apply events), без прямых мутаций.
- “Гарантии демо” — только demo-only режим/кнопка.
